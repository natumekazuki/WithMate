# Character Notes

## Target

- Character / Character ID:
- 対象の同一性・表現・作品／活動／創作設定との対応:
- 新規作成 / 改稿:
- 対象の定義範囲（表現・版・時点・言語・側面・関係のうち必要な軸）:
- 情報の開示範囲・提供資料の利用範囲:
- 作成・調査確認日:
- Default language: Japanese
- Runtime schema: withmate-character-v5
- Authoring revision: skill-v1 / 2026-10-04
- Notion parent URL:
- 指定した親page ID／取得状態（未取得ならunknownと理由）:

## Workflow State

- Authoring bundle revision / archive SHA-256:
- 現工程の読込範囲・参照（処理記録であり理解・遵守の証明ではない）:

- Mode: collaborative / one-shot
- Stage: research / alignment / calibration / validation / awaiting-approval / approved / provisional
- Candidate revision:
- Candidate runtime SHA-256（LF正規化後のファイル全体）:
- 現在採用中の版・hash・参照先:
- キャラ像の照合: pending / confirmed
- 呼ばれ方配列の確認: pending / confirmed / waived（対象配列・根拠はCharacter Address Evidence）
- Approval status: not-requested / pending / approved / waived
- 未解決の重要論点:
- 次に比較・確認する内容:

- 作業testの適用・理由・現在確認できた証拠範囲:
- one-shot / provisionalとする理由（該当時）:
- 同期希望: 承認後に実行 / 不要
- Deployment override: none / explicit
- Overrideの対象版・明示指示・未達事項（該当時）:

状態の意味と書き込み条件はprojectの`output-contract.md`を参照する。ここへpolicy全文をコピーしない。新しい会話ではこの状態と既知の合意から再開する。

### Dialogue Checkpoints

| Checkpoint | 状態 | 提示した内容・revision・発言参照 | 実ユーザーの回答参照・日時・短い記録 | 引継ぎ範囲／未決点 |
| --- | --- | --- | --- | --- |
| D1 / キャラ像 | pending |  |  |  |
| D2 / 候補出力評価 | pending |  |  |  |
| D3 / 対象版採用 | pending |  |  |  |

同じ実発言の全文を複製せず既存記録を参照する。ユーザー指定だけでD1を満たす場合は、声・距離・重要特徴を十分に特定した範囲を示す。対象の版・時点だけでは不足。D2は実際に提示した出力の後の評価であり、既存版の評価を未提示の新版への評価へ読み替えない。例外の省略・試用要求は実指示と対象範囲を記録する。

## Calibration Brief

- ユーザーの用途と会話体験の目標:

- 利用範囲: conversation-and-work（標準）/ conversation-only（明示指定）
- 対象作業（コーディング・調査・編集等）と、既知のtool・表示条件:
- 作業中に残す声・絡み方、途中報告や集中時の発話密度の希望:
- 対象にする表現・版・時点・相手との距離:
- 平常の声の温度・文の崩れ方:
- 平常の距離・絡み方・自己位置づけ:
- 提示する「ユーザーからの呼ばれ方」の候補配列・既知の確認（Character Address Evidence参照）:
- 感情の快・不快と活性、声の温度を分けた見立て:
- 特に残したい性質・短い言語特徴:
- 避けたい違和感:
- 既に確認済みで聞き直さない事項:
- 読者・視聴者の観察で重なる特徴・読みの差と作成側の仮説（根拠ID）:
- 次の1〜3論点と、答えが変える設計箇所:
- 照合日時・対象範囲・根拠となる会話参照:

## User Input Classification

ユーザー観察、強調希望、候補出力への評価、作成側の推定、自作設定の定義を分ける。事実確認の確度とは別欄で扱う。

| ID | 区分 | 内容の要約 | 会話・資料参照 | 事実確認の必要性・結果 | 設計へ反映する範囲 |
| --- | --- | --- | --- | --- | --- |

区分: user-observation / user-preference / output-feedback / authoring-inference / creator-definition

## Likeness Anchors / Approved Traits

失うと別人になる重要特徴。候補からユーザー確認へ進める。件数を埋めず、通常の会話で同時に残す声・距離・選択と、条件付き特徴を区別する。

| ID | 短い特徴ラベルと具体的な現れ方 | 平常 / 条件付き・出現機会 | runtimeの対応箇所 | source / ユーザー指定 | 確認状態・対象版 | 不足・過剰・退行の兆候 |
| --- | --- | --- | --- | --- | --- | --- |

- 特に保護する声・呼称・構文:
- 以前に良いと評価された箇所と対象版:
- 再調整する場合に確認が必要な性質:
- Anchor確認は最終版承認と同じか: 別 / 同一対象版について明示済み

## Feedback and Revision Log

| Revision / runtime hash | 比較した軸・入力参照 | 未編集出力の参照・環境 | 実ユーザーの指摘 | 原因仮説 | 変更箇所 | 再検証・退行 | 残る論点 |
| --- | --- | --- | --- | --- | --- | --- | --- |

- A/Bで固定した条件と、変えた条件:
- 後編集した作例がある場合の識別:
- 選別した出力・見せなかった失敗がある場合の扱い:
- 調整に使いholdoutから外した入力:
- 次のrevisionで維持する確認済みの良い点:

## Source Coverage Summary

| 範囲 | 確認状態 | 確認した媒体・内容 | 未確認・利用不能理由 |
| --- | --- | --- | --- |
| 設定の一次根拠（公式・原作・創作者設定等） |  |  |  |
| プロフィールの根拠（既存bioまたは一次設定からの要約） |  |  |  |
| 非公式Wiki・語録・fan site等の集約資料 |  |  |  |
| 個人の具体的な感想・考察・レビュー・公開コメント等 |  |  |  |
| 平常時の発話・本文・行動の材料 |  |  |  |
| 近い相手との応酬・関係の材料 |  |  |  |
| 状態差・平常への復帰 |  |  |  |
| 作業・挑戦等の進行中の発話・行動・設定 |  |  |  |
| Visual identity / color |  |  |  |

確認範囲は本文、画像、音声、映像、字幕、概要、タイトル、検索表示、リンク存在のみを区別する。各行は確認済み・partial・未確認・非該当等と探索範囲・理由を記録する。集約資料と個人の読みの両方を探索し、共通の転載元は束ねる。閲覧件数と特徴のcoverageを分け、プロフィール、直接観察、第三者の観察・受容・解釈、対話用設計を追跡する。

## Evidence / Sources

| ID | 提供者・Source class／資料の役割 | Title / URL / Ref | 確認日・対象の版／時点 | 原文・加工／確認材料・範囲 | 得た設定・発話・行為・受容・解釈 | 元の根拠・照合・独立性 | 主張の確度・用途適合性 |
| --- | --- | --- | --- | --- | --- | --- | --- |

Source classは資料の役割として記録する（一次設定・直接発話／行為・創作者設定・第三者の観察報告・受容／考察・編集抜粋等）。user-providedは入手経路であり、根拠の確度とは別。非公式という分類だけで低確度にせず、対象の事実／解釈／受容のどれを確認したかを示す。共通の元記事・場面・記述者が分かる場合は根拠IDを束ね、分からない独立性はunknownとする。依頼者の評価・承認はWorkflowとFeedbackの実発言で追跡する。

## Profile / Bio Sources

| Source / Account | URL / Ref | 確認日 | 現行 / 旧・媒体差 | 確認できたプロフィール要素 | descriptionへの採否 |
| --- | --- | --- | --- | --- | --- |

## Frontmatter Description Notes

- 採用したdescription:
- 変更前（改稿時）:
- 採用したプロフィール要素と根拠の種類:
- 確認sourceと日付:
- 本人のプロフィールへ要約・言い換えた点:
- 第三者説明・機能説明・会話開始文ではないこと:
- 既存bioの有無・対象範囲との差・不確実性:
- description実測文字数:

## Observation Log

| 公開例・状況・相手・時期 | 最初の着眼・連想 | 評価・意味づけ | 対人行為 | 感情と復帰の動き | 声・表記・口癖 | 確認媒体・Source | 観察と推定の境界 |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Primary Findings

| Source / 範囲 | 確認できた事実・発話・行為 | runtimeへの反映 | 信頼度・一般化の限界 |
| --- | --- | --- | --- |

## Secondary Source Findings

非公式の観察・受容・解釈から、らしさの詳細を採用候補へ移す。元sourceの未確認と、具体的な解釈としての有用性を分ける。既存EvidenceのIDを参照し、同じ本文を重ねて転記する必要はない。

| Source ID / Site | 具体的な特徴・場面・読み | 観察報告／受容／解釈の別 | 元の根拠・照合・独立性 | 採用 / 保留 / 不採用 | 対象適合性・確度・読みの差 |
| --- | --- | --- | --- | --- | --- |

### Secondary Leads Cross-Checked

| 採用候補・Source ID | 一次source・確認範囲 | confirmed / partial / conflicting / not-found | 設計への反映・留保 |
| --- | --- | --- | --- |

### Secondary-Only Observations

| 具体的な観察・解釈 / Source ID | 文脈・独立性・他資料との整合 | 依頼者の指定・確認 | 採否・採用強度 | 主張の確度・一次未確認の範囲 |
| --- | --- | --- | --- | --- |

## Derived Character Model

観察からの推定と合意した設計を記録する。資料に直接の発話がない場合の言語化、別言語への変換、任意の一人との関係・作業への移し方も、この既存欄から根拠を参照する。短いラベルを残し、具体的な文章への現れ方を添える。

### Baseline Presence

- 平常時の声・距離・絡み方・選択の組合せ:
- 感情の快・不快 / 活性 / 声の温度 / 親密さ:
- 状態にかかわらず残したい特徴:
- 特別な状況だけに閉じない特徴:

### Identity Core

- Self Position、自然に取る役割:
- 欲求・誇り・見栄・弱点・自己演出:
- 根拠と、公開personaからの推定範囲:

### Attention and Appraisal

- 最初に拾うもの・連想の手掛かり:
- 意味づけ、面白さ、価値の優先:
- 自分・相手・遊び・実害による違い:
- 他Characterと共有するが組合せへ効く要素:

### Social Intent

- 自分からの絡み方、相手へ起こそうとすること:
- 褒め、心配、からかい、張り合い、率直さの採用範囲:
- 成功・失敗・食い違い・修復への乗り方:
- 共感や助言へ常に回収しない会話上の目的:

### Emotional Dynamics

- 基準温度、立ち上がり、表出、ずらし方:
- 収まり方と普段へ戻るきっかけ:
- Character自身と相手の状態の区別:

### Thinking / Action Style

- 不確実さや失敗への初動:
- 判断・比較の軸:
- 説明の語順、途中に残る声:

- 作業での発見・見立ての修正・部分成功・割り込みに残る特徴:
- ユーザーの失敗、自分の判断・変更、環境障害を分けた反応:

### Core Tensions

| 通常傾向 | 変化する条件 | 変わるもの | 残る声・距離・選択 | 平常への復帰 | 根拠・確度 |
| --- | --- | --- | --- | --- | --- |

## Language Identity Analysis

### Identity Invariants

| Feature | 採用表記・規則 | Source / ユーザー指定 | 相手・場面・媒体差 | 確度 / 設計上の解釈 |
| --- | --- | --- | --- | --- |
| 一人称 |  |  |  |  |
| 基本呼称（Character → ユーザー） |  |  |  |  |
| 補助呼称（Character → ユーザー） |  |  |  |  |
| ユーザーからの呼ばれ方（User → Characterの文字列配列） |  |  |  |  |
| 敬語度 |  |  |  |  |
| 重要な表記 |  |  |  |  |

### Distributional Tendencies

| Feature | 平常の出方 | 強まる / 弱まる文脈 | 採用する具体語・構文型 | source / 確度 | 出力での確認 |
| --- | --- | --- | --- | --- | --- |
| 文長・切り方・間 |  |  |  |  |  |
| 語順・言い直し・反語 |  |  |  |  |  |
| 語尾・助詞 |  |  |  |  |  |
| 語彙・俗語 |  |  |  |  |  |
| 感嘆・笑い・伸ばし |  |  |  |  |  |
| 主語・呼称の省略 |  |  |  |  |  |

### Triggered Marker Evidence

| Marker / exact表記 | Type | Trigger | Function | Intensity / Placement | Frequency・強弱の条件 | Variation | source・確度 |
| --- | --- | --- | --- | --- | --- | --- | --- |

Type: habitual / reactive / signature。広い習慣は広い条件のまま扱う。全タイプを埋める必要はない。

### Frequency and Strength Separation

| Marker / Feature | 本人の観察頻度・対象期間・母集団 | 根拠の信頼度 | runtimeの出現方針 | 語気の強さ | ユーザー確認・調整理由 |
| --- | --- | --- | --- | --- | --- |

実測していない回数・確率は記入しない。観察頻度不明と、採用上の低頻度を混同しない。

### Association and Meme Response

- 採用の必要性・対象範囲:
- 連想の手掛かり:
- 反応の入り方、話題へのずらし方、相手への乗り方:
- 短い採用語・構文型と本人使用の根拠:
- 時期・媒体差、未確認の使用歴:
- 自然入力で連想が出たか、過剰なネタ挿入にならないか:
- 非該当の場合の理由:

## User Address Evidence

Character → ユーザーの呼称を扱う。基本呼称・補助呼称・使用頻度の規則を、逆方向の呼ばれ方配列へ適用しない。

| 呼称・表記 | 相手・場面・語気 | Source / 確認範囲 | 集団 / 単数 | 観察頻度 | runtimeへの採否・設計解釈 |
| --- | --- | --- | --- | --- | --- |

- 基本呼称と通常の省略方針:
- 主な使用場面と出やすさ:
- 語気調整、補助呼称の限定場面:
- 参照資料で確定できない場合の選定理由:
- ユーザーとの声・距離の照合結果:

## Character Address Evidence

「ユーザーからの呼ばれ方」（User → Character）を扱う。runtimeの値は同列の文字列配列のみ。基本・既定・優先・推奨は設けず、並び順に順位の意味はない。ここでの出典や採否の情報を配列要素の属性へ変換しない。

- 提示した候補配列（文字列のみ・順位なし）:
- runtime採用配列（character.mdと同じ表記・並び）:
- 配列の確認状態: pending / confirmed / waived
- 提示・確認した日時、対象revision、会話参照:
- ユーザーによる追加・削除・表記修正、または既知の明示指定:
- 未確認点／確認省略の明示指示・理由（該当時）:
- 配列の確認と最終runtime承認の区別:
- 呼びかけ認識の確認（既存test名、入力・未編集出力参照、結果・未実施範囲）:

| 呼ばれ方・正確な表記 | Source / ユーザー指定・確認範囲 | 公開の使用文脈・事実と設計の区別 | 採用 / 保留 / 不採用・理由 |
| --- | --- | --- | --- |

名前・略称・愛称の存在と、本人が好む・特定の反応をするという主張を分ける。採用数を埋める創作や、ユーザーへの呼称の強制をしない。同じ配列の確認は引き継ぎ、未確認をconfirmedにしない。配列変更後の確認・承認は`output-contract.md`に従う。

## Relationship Interpretation

- 初期関係と親しさの強さ:
- 公開の相手固有の関係と、任意ユーザーへの変換を分けた根拠:
- 自分からの絡み、馴れ馴れしさ、率直さ、からかいの基準:
- 相手の返しに乗る方法・本気の不快への調整:
- 成功・失敗・心配・意見不一致・修復の固有性:
- 恋愛・独占・依存を採用する場合の明示指定と境界:
- 会話内の共有と、存在しない記憶を作らない範囲:
- 一般的な優しい相棒へ薄めていないことの確認:

## State Modulation Design

| 状態・きっかけ | 注意・評価・対人目的 | 変える声・文量・呼称・marker | 残す成分 | 普段への復帰条件 | 根拠・出力確認 |
| --- | --- | --- | --- | --- | --- |

Characterに必要な状態だけ記録する。真剣・長文・不一致を全marker停止の共通条件にしない。

## Work-session Design

作業用途で使用する。会話専用なら非該当理由を残し、詳細の空欄は削除できる。作業の台本ではなく、既存の声・距離・選び方が作業へどう現れるかを記録する。

- 対象タスク領域・利用範囲と、その根拠となる依頼:
- 合意した作業中の声・距離・発話密度:
- 対象の作業・挑戦等を資料で直接確認した範囲:
- 別文脈から移した設計上の解釈と、未確認の本人経験:
- 普段の性質のうち中盤にも残すもの・runtime対応箇所:
- 集中・途中の質問・方針変更・中止・再開・平常への復帰:
- 話す声と成果物の形式・文体を分ける方針:
- 想定する表示面・注入範囲とunknownの項目:
- 非該当の場合の明示指定・理由:

| 元の観察・Source / ユーザー指定 | 移す声・反応・判断の特徴 | 作業での発生文脈 | 残すもの・変えるもの | authoring-inferenceの範囲 | ユーザー確認・対象revision |
| --- | --- | --- | --- | --- | --- |

自分の見立ての修正を、ユーザーへの励ましで代用しない。常用する失敗、偽の進捗、特定のtoolを使う固定手順は人格へ採用しない。

## Runtime Handoff

| 観察 / 合意した性質 | runtimeの規則・箇所 | 保持した具体語・構文 | 複数場面・限定場面への働き | source / 解釈 | 採用理由 |
| --- | --- | --- | --- | --- | --- |

### Runtime Closure Review

採用する人物情報の意味の十分性と、原則肯定形による定義を確認する。具体的な声・性質の保持、削除・統合した不要な予防文を、必要な範囲で既存の参照へ結び付ける。

- 対象runtime SHA-256:
- Review status: not-run
- Review evidence:

| 採用固有情報／依存表現 | 本文上の役割・意味を確定する箇所 | 必要性と、維持／定義補完／削除の判断 | source確認・未解決点の参照 |
| --- | --- | --- | --- |

一般語すべての用語集にはしない。名前・認識用別名はその役割で閉じることを確認する。不採用語と対象版・時点等の作成指定は本notesへ一度記録しruntimeへ戻さない。意味監査の環境（authoring-review等）、実施範囲、既存testと共用した出力確認、残件をReview evidenceの参照先へ記録する。構造検査は上記status/hash/記録の非空だけを確認し、意味や真正性を認証しない。

### Documentation-only / Rejected Ideas

| 候補・旧要素 | 採用しない / 保留する理由 | 確認が必要な点 |
| --- | --- | --- |

### Minimal Reliability and Boundaries

- runtimeに残した肯定形の実行・確認・共有履歴の扱い:
- Base Runtimeへ任せた一般的な作業・信頼性規則:
- 採用した性質・表現の文脈と強度:

## Compression and Signal Density

- 声と距離の校正が済んだ対象revision:
- 圧縮前後のrevision・文字数・bytes:
- token数と計測手段・モデル（未計測はnot-measured）:
- 削除・統合した重複、一般手順、背景:
- 保持した短いラベル、一人称、呼称、構文、口癖:
- 他人と共有しても組合せに効くため残した特徴:
- 固定返答から移した具体的なsignalと生成規則:
- Ablationの対象・結果・未実施範囲:
- 圧縮後のanchor・声・自然出現・holdout再確認:

## Conflicts / Uncertainty

| 項目 | 競合・欠測・媒体差・時期差 | 採用した解釈 | ユーザー確認 | 残る検証・扱い |
| --- | --- | --- | --- | --- |

## Visual Identity / Color Notes

| Role | HEX（sRGB） | 決定区分 | Source / 確認日 | 対象箇所・方法 | 理由・役割 | 確度・不確実性 |
| --- | --- | --- | --- | --- | --- | --- |
| メインカラー |  |  |  |  |  |  |
| サブカラー |  |  |  |  |  |  |

- 決定区分: official-published / official-sampled / authoring-derived
- 公式コード・明示色を確認できた範囲:
- community候補と一次照合:
- 肌・影・ハイライト・背景・透過・圧縮ノイズを除いた方法:
- 既存値から変更する場合の理由:
- 承認対象のメインHEX / サブHEX:
- 画像そのものは標準Packへ入れないこと:

## Revision Notes

- 改稿前後の構造・description・文字数:
- 既存の良かった特徴と保持方法:
- 旧来の抑制・優先順位・一般化から直した点:
- 追加調査、言語規則、状態差の変更:
- 関係性・呼称・色の変更と根拠:
- 旧評価を新revisionへ移していないこと:

## Validation Summary

### Environment and Provenance

- 対象revision / runtime hash:
- Environment: authoring-preview / isolated-runtime / withmate-runtime

- 作業イベント出所: synthetic-event / recorded-tool-replay / live-tool-execution（非作業時はnot-applicable、混在時はevent別に記録）
- Dialogue mode: single-turn / scripted-dialogue / user-dialogue
- モデル・設定・Base Runtime・注入範囲・履歴（不明はunknown）:
- 実行方法・実際の試行数:
- 入力と未編集出力の参照・保存状況:
- 作例・後編集・選別がある場合の区別:
- 実ユーザーの評価を得た範囲:
- 未検証の環境・制約:

### File and Evidence

| 項目 | 実測・状態 | 根拠 / 留保 |
| --- | --- | --- |
| runtime文字数（全体・LF） | / 8,000 |  |
| runtime UTF-8 bytes |  |  |
| description文字数 | / 160目安 |  |
| notes bytes | / 256 KiB目安 |  |
| frontmatter・必須役割・日本語 |  |  |
| 一人称・基本呼称・voice・marker6属性 |  |  |
| 呼ばれ方の文字列配列・順位なし・notesとruntime一致 |  |  |
| 完成返答Examplesなし・runtime/notes分離 |  |  |
| 対象の一次・二次資料の適用／取得範囲 |  |  |
| 事実・ユーザー指定・推定の区別 |  |  |
| HEX・色source・rights |  |  |

### Main Quality Tests

結果: pass / fail / inconclusive / not-run / not-applicable。理由と実施範囲を必ず添える。

| Test | 結果 | 入力・出力参照 / 件数 | 確認した特徴・失敗 | 環境・ユーザー確認・限界 |
| --- | --- | --- | --- | --- |
| Baseline / Anchor-presence |  |  |  |  |
| Voice-restoration |  |  |  |  |
| Marker-underuse |  |  |  |  |
| Marker-overuse |  |  |  |  |
| Unseen-scenario（3件以上） |  |  |  |  |
| Paraphrase diversity（同義3件） |  |  |  |  |
| Core-tension |  |  |  |  |
| Long-form retention |  |  |  |  |
| 7-scene relationship smoke test |  |  |  |  |
| Multi-turn continuity / Return-to-baseline |  |  |  |  |
| Task-execution / Conversation-work Continuity（作業用途で必須） |  |  |  |  |
| Regression / Protected-trait |  |  |  |  |

### Natural Marker Opportunity Log

| Marker / Type | 対象revision・条件 | 返答数 | 出現機会のある返答数 | 使用した返答数 / 総出現数 | 不足・過剰の解釈 / 標本の限界 |
| --- | --- | --- | --- | --- | --- |

marker名を入力で指定した試行は、自然出現とは別枠にする。

### Required Diagnostics

| Test | 実施範囲・結果 | 見つかった依存・組合せ | 変更した点 / 変更しない理由 |
| --- | --- | --- | --- |
| Name-swap / Combination |  |  |  |
| Phrase-suppression |  |  |  |
| Compression / Ablation |  |  |  |

診断を実施したことと、通常版の品質を確認したことを分ける。

### Continuous Conversation Record

- 実ユーザー / scriptedの区別:
- 対象revision・実際の往復数・会話参照:
- 話題と状態の移行:
- 中盤の声・距離・型の反復:
- 普段へ戻れたか:
- ユーザーが感じた長時間の違和感:
- 確認できなかった遷移・今後の課題:

### Work-session Validation Record

EnvironmentとEvent sourceは別軸で記録する。必要なセッションごとに表を追加し、結果を先に書かない。taskの初期状態やログの参照が利用不能なら、その限界も記録する。

#### Task and Execution Conditions

- Session / task ID、候補revision / runtime hash:
- 対象領域、調整用 / holdout、通常経路 / 想定外経路:
- ユーザー依頼・初期資料やファイルの版・受入条件:
- Environment / Dialogue mode / Event source:
- モデル・設定・Base Runtime・tool構成・権限・初期状態の復元方法:
- 検証用コピー / sandboxの範囲、外部への副作用の許可:
- 途中発話・最終回答の表示面、各段階のCharacter注入、履歴・ログ省略:
- 長いコード・ログを読んだ位置と、その後の発話参照:
- 観測可能な範囲・不明な段階・別エージェントの発話:
- 実際の試行数、ユーザー往復数、tool実行数（それぞれ実測）:
- A/Bで同じにした条件と、枝分かれ・環境差:

#### Event and Visible Response Trace

| 順序 / event ID | その時点の入力・分かった事実の参照 | Event source・元ログ・加工の有無 | 候補の行為・tool結果の参照 | 未編集のユーザー向け発話の参照 | 変更後の状態・残件 | anchor / 発話が必要な機会・無言が適切な機会 |
| --- | --- | --- | --- | --- | --- | --- |

- 未来の結果を提示せず、選んだ行為と次のイベントを整合させた範囲:
- 見立ての誤り / 自己変更 / 既存不具合 / 環境障害の区分と証拠:
- 自然に起きなかった反応機会を別試行で補った範囲・出所:
- 実ユーザーの途中質問・変更・中止と、その後の再開・復帰:
- scriptedな割り込みと実ユーザーの発言の区別:
- 開始・中盤・検証・引き渡し・会話復帰のcoverage:
- 伏せた秘密情報・省略・欠落・参照不能による限界:

#### Three-axis Assessment and Functional Verification

| Axis | 結果 | 根拠となるevent / 出力 | 実ユーザー評価 / 作成者評価の区別 | 証拠範囲・未確認 |
| --- | --- | --- | --- | --- |
| Work Likeness |  |  |  |  |
| Task Integrity |  |  |  |  |
| Collaboration Comfort |  |  |  |  |

- Functional verification: pass / fail / inconclusive / not-run / not-applicable
- 実際に編集・実行した範囲、差分、受入条件との照合:
- 実行したテスト・確認と実結果、未実行・部分成功・残件:
- シミュレーション / replayだけの時に実作業の確認をnot-runとしたこと:
- 作業test全体の結果・3軸の判定根拠・限定範囲:
- 発話密度と必要な共有、同じ反応の反復・不足の解釈:
- 成果物の形式・文体・コード等への無目的なキャラ語混入の有無:
- 調整に使っていない作業入力と、その検証結果:
- 実機・実行能力・UI・注入条件について主張できない範囲:
- 圧縮・改稿後に守れた作業中の特徴と、通常会話の退行検査:

結果はpass / fail / inconclusive / not-run / not-applicable。synthetic-eventやreplayのみのFunctional verificationはnot-run。3軸のpassを、実際の編集や機能検証のpassへ置き換えない。後編集した作例や非公開の内部思考は原出力証拠にしない。

### Decision

- Gate A（形式・証拠・権利）:
- Gate B（声・会話品質・対象用途の作業品質）:
- Gate C（対象版承認）:
- 解消した重要フィードバック:
- 未達・未検証と、provisionalまたは承認範囲の扱い:
- 総合点だけで重要特徴の欠落を相殺していないこと:

## Approval Record

- Approval status: not-requested / pending / approved / waived
- 対象revision / runtime hash:
- 対象メインHEX / サブHEX:
- ユーザーに提示した本文・候補出力・検証範囲:
- 明示的な採用の確認日・会話参照または短い記録:
- alignmentのみの確認と区別した根拠:
- 呼ばれ方配列の確認状態・記録参照（Character Address Evidence）:
- 承認に含まれる環境、未検証事項の開示:

- 承認に含まれる対象タスク・イベント出所・機能検証範囲:
- 実作業・表示・注入条件が未検証の場合の限定承認の根拠:
- 例外の配布・同期指示と対象範囲:
- 承認後の変更の有無・再承認要否:

## Packaging

- 対象revision / runtime hash:
- Zip内のfile数・名前・階層の実測:
- root直下: character.md / character-notes.md
- 余分なfile / directory:
- 展開後の最終原稿とのbyte比較:
- 最終notesの反映と再パッケージの確認:
- 確認日:

## Notion Sync Summary

- Sync requested: yes / no
- Status: synced / pending / skipped / failed
- Write gate: approved / explicit-override / blocked
- 書き込み対象revision / runtime hash:
- Approval recordとの対応:
- Characters database / data source:
- Match method: user-supplied-parent-url / pinned-page-id
- Name安全照合: nameと取得NameのNFC・trim後完全一致（探索には使わない）
- 指定親の同一性・必要property・親直下の子完全取得:
- 既存採用版の同時更新の確認:
- Parent action: updated / unchanged / not-run
- Parent URL:
- Default template: user-managed（この工程では適用しない）
- character.md action / URL:
- character-notes.md action / URL:
- Name / メインカラー / サブカラー:
- ChatGPT Character Authoring: preserved / unavailable / not-applicable（設定・変更はしない）
- 保持した他property:
- 再取得した一意性・HEX・各単一markdownコードブロック:
- 両ファイル全文のローカル最終版との一致:
- 最終notes再同期・再取得結果:
- 同期日時:
- 未実行・失敗理由・途中まで完了したaction:
- 再試行時に再利用する既存URL:

## Asset / Rights Notes

- 対象の一次設定・公開persona・創作者定義／ユーザー指定の解釈の範囲:
- 公認・監修・許諾について実際に確認した範囲:
- 長い台詞・作品本文・歌詞の転載を含まないこと:
- 色の参照画像と配布権の区別:
- 別添assetの明示依頼、source、rights、受け渡し方法（扱った場合のみ）:

## Future Improvements

承認した版で残る環境上の限界、追加調査、実環境で見たい点を、完了済みと混同せず記録する。
