---
name: withmate-character-authoring
description: >-
  WithMate V5のCharacterPackを調査・対話・試演・実ユーザー評価で新規作成／改稿する。
  「キャラパックを作成」「キャラクター定義を作る」「character.mdを改善」や既存候補の調整・検証・承認済み版の同期で使う。
  アニメ・ゲーム・VTuber・オリジナルなど対象共通。初回はキャラ像照合を返し、次の実ユーザー入力から候補試演へ進む。
  一般的な作品解説、単発ロールプレイ、作成仕様の相談だけには個別キャラ制作を開始しない。
---

# WithMate Character Authoring

Version: 1.0.2 / skill-v1 / 2026-10-04
Basis: zip-workflow-r5。作成側のSkillであり、生成するCharacter自身のruntimeとは別物。

## この応答の仕事

初めに、現在の実ユーザー入力・既知の合意・最新notesから下表の仕事を一つ選ぶ。新規の「作成して」は、対話セッションの開始依頼として**初期調査とキャラ像照合**を行う。版・時点・関係性・ネタバレ指定は照合案へ反映する。

| 今回の仕事 | 条件 | 開くガイド | 返す成果と終了点 |
| --- | --- | --- | --- |
| キャラ像照合 | 新規初回／重要な再照合 | [research.md](references/research.md) | 根拠付きの声・距離・重要特徴、呼ばれ方候補配列、重要な1〜3論点を最終応答に返し、終了 |
| 試演・調整 | キャラ像を照合済み／候補への修正 | [drafting.md](references/drafting.md) | 候補を保存・単体検査し、その版の未編集試演と評価点を最終応答に返し、終了 |
| 検証・承認照合 | 提示候補への実評価があり主要な違和感が解消 | [validation.md](references/validation.md) | 必要な検証、候補本文・revision/hash・2色・限界を返し、必要な対話／対象版承認を受ける |
| 確定・同期 | 提示済み同一版への実採用承認がある | [deployment.md](references/deployment.md) | 同一本文の同期と最終2ファイルZipを照合して返す |

**初回の完成対象は照合案。全runtime・全notes・全品質試験・色の確定・Pack配布へ先回りしない。** 質問を進捗報告へ書いて作業を続行するのでなく、最終応答で返す。次の仕事は次の実ユーザー入力を受けてから開始する。

再開時は[workflow.md](references/workflow.md)と最新notesを読む。既回答・同じ呼ばれ方集合・同じ対象版の承認を引き継ぐ。キャラ像への賛同、候補出力への評価、最終候補の採用承認を区別する。「続けて」「おまかせ」や詳細な設定指定は対話省略に読み替えない。

明示的な確認省略・一度での作成だけはone-shotとしてprovisional / waivedにする。途中試用や対象版へのdeployment_overrideも、[契約](references/output-contract.md)の明示範囲で扱う。provisionalは品質・承認状態であり、対話省略の許可ではない。

仕様相談・資料監査・このSkillの更新は、その依頼の成果を返す別作業。個別キャラの調査・試演・Notion書込を自動で開始しない。

## 調査と人物像

キャラクターとして定義する存在全般を同じ構造・採否・品質条件で扱う。公式・一次設定・創作者設定で輪郭を確かめ、非公式Wiki・語録・エピソード集と個人の具体的な感想・考察・公開コメントを広く探して、声・距離・反応の詳細を組み立てる。

非公式資料は主要な解釈材料。具体性、前後文脈、独立性、対象の版・時点との適合性で評価する。公式の未記載と設定事実との矛盾を分け、全特徴の一次照合を候補化の前提にしない。設定・直接観察・第三者の受容・解釈・対話用設計はnotesで区分する。情報源の確度と性質・口癖の強さは別軸。外部の好評は依頼者の出力評価・承認の代用ではない。

詳細は[Source Policy](references/source-and-rights-policy.md)。音声・映像・字幕・本文・検索表示の確認範囲を実態どおり記録する。資料が少ない対象や創作者指定も、同じ照合・試演へ進める。

## character.mdの執筆原則

`character.md`は、その人物として未知の会話と実作業への反応を生む定義。その版で採用する事実・性質・着眼・欲求・声・距離・状態を**原則肯定形で直接書く**。

必要な固有情報は、frontmatterを含む本文だけで意味・本人との関係・現在状態・使用条件が分かるよう記す。不要な情報は、名称・暗示・禁止文ごと省く。不要な予防文は行全体を削除し、必要な採用規則だけを残す。根拠・比較・不採用・作成経緯はnotesへ置く。モデルの既有知識や原作・別冊への依存を本文の補足手段にしない。

選択と声を一体で定義し、短い性質ラベル、正確な一人称、呼称、語尾、構文、口癖を採用した強さで保つ。気だるさ、雑な絡み、見栄、張り合い等も対象の根拠と合意に沿って残す。短縮や無難さを目的にしない。完成返答例・初回メッセージは作成側の試演に分離する。

執筆時は[構成原則](references/runtime-self-containment.md)、[Format](references/withmate-v5-character-format.md)、[共通必須項目](references/required-properties.md)、[本文雛形](assets/character.md)を使う。採用集合から組み立て、各文が何の生成情報に効くかを本文だけで確かめる。

## 共通形式

frontmatterは`schema: withmate-character-v5`、`name`、`description`の3キー。本文は日本語、固定名の10個のH2を保持する。

`character.md`の`description`は、キャラ本人が相手へ直接語る簡潔な自己紹介とする。本人の一人称・口調・語尾・距離感で、採用済みの立場・活動・好きなこと・得意・目標などを伝える。「〜というキャラクター」「彼女は〜」の第三者紹介や作成者の解説にしない。「私」を一律に付けず、主語省略や自分の名前を一人称にする話し方も含め、Voice Rulesに合わせる。1〜3文・160文字以内を目安にする。各資料でdescriptionを「プロフィール」「bio」と呼ぶ場合も、この本人視点の自己紹介を指す。根拠と具体的な確認条件はFormatのFrontmatter Descriptionに従う。プラグイン／Skill自体のdescriptionはこの要件の対象外。

本人に特徴的な挨拶・名乗りがある場合（VTuberの定番挨拶など）は、表記と使用文脈を確認し、descriptionの冒頭などへ自然に取り入れる。ない場合は無理に作らない。通常会話の毎ターン挨拶とは分ける。

Identity Invariantsは「一人称」「ユーザーの呼び方」「ユーザーからの呼ばれ方」「敬語度・表記」、Distributional Tendenciesは「文・テンポ」「構文・語尾」「語彙・表記」を独立した`- ラベル: 値`で保持する。「ユーザーからの呼ばれ方」は同列の空でない文字列1件以上の重複なしJSON配列。任意項目は採用するものを残す。

候補本文だけの検査と、最終Pack検査を分ける。LF正規化後のファイル全体で8,000文字以内。最低文字数・目標帯は設けない。最終CharacterPackはZip直下の`character.md`と`character-notes.md`のみ。

## 状態・試演・検証

案件の状態は[notes雛形](assets/character-notes.md)のWorkflow State / Dialogue Checkpointsへ差分記録する。D1=キャラ像の実照合、D2=提示した候補への実評価、D3=提示済み同一版の採用。revision/hash、提示、実際の回答、未解決点を対応させる。管理コード・検査結果だけで実ユーザーの確認を生成しない。

指摘された現象→原因仮説→規則変更→別入力で再確認。確認済みの良い声・性質を退行検査する。未編集の通常生成・継続対話を主評価とし、[Rubric](references/authoring-rubric.md)の主品質test・診断と[Checklist](references/review-checklist.md)を維持する。

標準用途はconversation-and-work。作業の中盤、割り込み、会話への復帰も確認する。authoring-preview / isolated-runtime / withmate-runtime、実ユーザー／scripted、synthetic-event / recorded-tool-replay / live-tool-executionを区別する。未実施はnot-run、不明はunknown、根拠不足はinconclusive。構造検査、意味監査、実出力の品質、実作業の成功、採用承認はそれぞれ別に判定する。

## 利用するファイルとツール

ガイドからその工程の原文だけを読み込む。登録済みSkillの参照機構、または存在を確認したSkillディレクトリを使う。Source Zipの取得・展開は起動手順から外した。

Python 3.10以上と実ファイルが利用できる時は、同梱コードを確認してから以下を実行する。コマンドはSkillルート基準。案件の入力パスは実在するものを使い、候補と成果物はSkill外へ保存する。

```bash
python -B scripts/validate_pack.py --runtime-only /path/to/candidate/character.md
python -B scripts/validate_pack.py /path/to/final/CharacterPack.zip --reference-dir /path/to/final/files
```

[read_stage.py](scripts/read_stage.py)は工程原文の分割表示、[validate_pack.py](scripts/validate_pack.py)は構造・記録整合の検査。Pythonや同梱スクリプトが利用不能なら、その未実行範囲を明示し、読める原文と現工程の成果まで返す。これらのスクリプトはユーザー返答待ちを強制する外部コントローラでも、承認の真正性検証でもない。

## Notionと引渡し

キャラ案件は事前作成済み親ページURL1件を必須とし、同一案件では再利用する。指定先を対応connectorで直接読み、実際のschemaに従う。親の名前探索・新規作成・template設定は作業対象外。

書込は同一版の採用承認または対象版への明示override後。親の既存2色以外のpropertyを保持し、両子をそれぞれ単一markdownコードブロックにする。重複確認、同時更新の確認、親と両子の再取得、全文照合、最終notesの再同期・再取得を[同期契約](references/output-contract.md)どおり実施する。

接続失敗と承認待ちを分けて記録する。最終Zipは原稿とbyte比較し、実行した範囲を添えて渡す。このSkillの作成・登録自体では既存キャラやNotionを変更しない。
