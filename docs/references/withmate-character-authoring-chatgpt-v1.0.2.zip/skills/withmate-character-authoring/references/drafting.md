# Drafting, Preview, and Calibration
Revision: skill-v1 / 2026-10-04

採用する事実・性質・声・関係・状態を、既存notesのDerived Character Model / Language Identity Analysis / Runtime Handoffから抽出して執筆する。根拠の台帳や不採用例は本文の材料へ転記しない。意味の閉じた肯定形の定義を作り、具体的な特徴と強度を保つ。

候補本文を保存しrevision/hashを識別、単体構造検査と本文だけの意味監査を行う。少数の自然入力への未編集出力を示す。必要なら同じ入力・条件で少数の軸を変えた比較を使う。現在の作成文脈を含む試演はauthoring-previewと記録する。

今回返す成果は候補の試演と照合点。実ユーザーが評価した後に修正・再試演へ進む。全notes、色、全品質testの事前完成を候補単体検査の条件にしない。

## 読む順序

以下は`read-plan.json`の同じ仕事に対応する原文範囲。新規はnew、改稿はreviseの項目を使い、共通項目は両方に適用する。同じ版の原文が現在の文脈に残っていれば重複表示を省く。未来の工程の資料を先読みして、その仕事まで実行する手順ではない。

### 30-calibration — 候補定義・試演・修正

その版の採用人物情報から肯定形の候補を作り、本文単体を検査して未編集試演を提示する。今回の成果は試演・調整である。

- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Evidence to Interpretation`（共通）
- [references/runtime-self-containment.md](runtime-self-containment.md) — `全文`（共通）
- [references/required-properties.md](required-properties.md) — `全文`（共通）
- [references/output-contract.md](output-contract.md) — `## Dialogue Turn Boundaries`（共通）
- [references/withmate-v5-character-format.md](withmate-v5-character-format.md) — `全文`（共通）
- [assets/character.md](../assets/character.md) — `全文`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `### 3. Define the Baseline and Protected Traits`（new）
- [references/new-character-pack.md](new-character-pack.md) — `### 4. Design Voice and State`（new）
- [references/new-character-pack.md](new-character-pack.md) — `### 5. Prototype and Show Unedited Outputs`（new）
- [references/new-character-pack.md](new-character-pack.md) — `### 6. Revise by Cause, Not by Accumulation`（new）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 7. Rewrite the Runtime without Sanitizing`（revise）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 8. Compare Outputs and Revise by Cause`（revise）
- [references/authoring-rubric.md](authoring-rubric.md) — `## Evaluation Environments`（共通）
- [references/authoring-rubric.md](authoring-rubric.md) — `## Test Protocol`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Feedback and Revision Log`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Source Coverage Summary`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Evidence / Sources`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Secondary Source Findings`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Frontmatter Description Notes`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Observation Log`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Derived Character Model`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Language Identity Analysis`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## User Address Evidence`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Relationship Interpretation`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## State Modulation Design`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Work-session Design`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Runtime Handoff`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Conflicts / Uncertainty`（共通）

**この段階の境界:** 候補出力への実ユーザー評価を受ける最終応答で終了する。全notes・色・全検証の事前完成を条件にしない。

## ファイル読込を補助する場合

登録先の参照機構で直接読む方法を標準とする。実ファイルが使える場合はSkillルートで次を使い、表示された全PARTを末尾まで読む。

```bash
python -B scripts/read_stage.py --stage 30-calibration --kind new --part 1
```

改稿は`--kind revise`。ガイド内の次の段階も、同じ応答の仕事の範囲で読む。表示は原文取得の記録であり、実ユーザー評価や承認の代用ではない。
