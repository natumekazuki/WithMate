# Approved Deployment and Packaging
Revision: skill-v1 / 2026-10-04

対象版の実採用承認、またはその版への明示overrideを確認してから実行する。Notionの操作は今利用できる対応connectorのschemaを読み、実在する指定親URL / page IDへ行う。名前検索や親作成へ切り替えない。

親と両子の同一性・一意性と変更を再取得で確かめ、既存2色以外のpropertyを保つ。各子は単一markdownコードブロックの全文を照合する。最終notesを再同期・再取得し、実結果と未完部分を分ける。前もって未来の照合成功を記録しない。

最終2ファイルをZip直下へ格納し、構造検査と最終原稿とのbyte比較を行う。同期失敗でも可能なローカルPackと正直な状態を返す。作成済み子IDを再利用する。Skillの仕様ファイル・テスト・ログはCharacterPackへ同梱しない。

## 読む順序

以下は`read-plan.json`の同じ仕事に対応する原文範囲。新規はnew、改稿はreviseの項目を使い、共通項目は両方に適用する。同じ版の原文が現在の文脈に残っていれば重複表示を省く。未来の工程の資料を先読みして、その仕事まで実行する手順ではない。

### 60-delivery — 指定親同期・2ファイル納品

同じ承認済み本文だけを指定親へ反映。再取得・全文照合・最終notes反映後のZip実体検査を行う。

- [references/output-contract.md](output-contract.md) — `## Standard CharacterPack Deliverable`（共通）
- [references/output-contract.md](output-contract.md) — `## Dialogue Turn Boundaries`（共通）
- [references/output-contract.md](output-contract.md) — `## Required Notion Parent URL`（共通）
- [references/output-contract.md](output-contract.md) — `## Notion Handoff — Write Gate`（共通）
- [references/output-contract.md](output-contract.md) — `## Notion Synchronization Procedure`（共通）
- [references/output-contract.md](output-contract.md) — `## Packaging Validation`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `### 10. Approve, Package, and Sync`（new）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 11. Deliver and Synchronize`（revise）
- [assets/character-notes.md](../assets/character-notes.md) — `## Packaging`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Notion Sync Summary`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Notion Synchronization`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Packaging and Separate Assets`（共通）

**この段階の境界:** 未承認は書込停止。同期失敗を隠さずローカルPackを渡す。検査後に本文を整形し直さない。

## ファイル読込を補助する場合

登録先の参照機構で直接読む方法を標準とする。実ファイルが使える場合はSkillルートで次を使い、表示された全PARTを末尾まで読む。

```bash
python -B scripts/read_stage.py --stage 60-delivery --kind new --part 1
```

改稿は`--kind revise`。ガイド内の次の段階も、同じ応答の仕事の範囲で読む。表示は原文取得の記録であり、実ユーザー評価や承認の代用ではない。
