# Validation and Candidate Approval
Revision: skill-v1 / 2026-10-04

候補への実ユーザー評価を確認してから、そのrevision/hashの品質を検証する。通常生成、同義3入力、未見3入力以上、長文、状態の往復、継続対話、関係7場面、作業中盤と会話への復帰を扱う。Name-swap / Phrase-suppressionを診断として分け、改稿・圧縮は確認済み特徴を退行検査する。

適用条件を満たす同一版のログは複数testで共用できるが、結果・根拠は各々記録する。実施した試験と未実施を分け、必要な継続対話は実ユーザーとの次の応答へ分割する。主要な違和感が残れば調整へ戻る。

対象本文、revision/hash、2色、変更と検証環境・限界を提示し、その版への採用を受ける。品質の必須未達は総合点で相殺しない。承認用の途中Packを示す場合も2ファイル構成とGate Aを満たす。承認前に通常のNotion書込へ進まない。

## 読む順序

以下は`read-plan.json`の同じ仕事に対応する原文範囲。新規はnew、改稿はreviseの項目を使い、共通項目は両方に適用する。同じ版の原文が現在の文脈に残っていれば重複表示を省く。未来の工程の資料を先読みして、その仕事まで実行する手順ではない。

### 40-validation — 通常・継続・作業・未見検証

D2後の対象本文について、自己完結性、主品質test、必須診断を検証。構造検査と意味検査・ユーザー評価を別に記録する。

- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Source Coverage Rule`（共通）
- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Evidence to Interpretation`（共通）
- [references/runtime-self-containment.md](runtime-self-containment.md) — `全文`（共通）
- [references/authoring-rubric.md](authoring-rubric.md) — `全文`（共通）
- [references/output-contract.md](output-contract.md) — `## Completion, Provisional Delivery, and Waivers`（共通）
- [references/output-contract.md](output-contract.md) — `## Work-session Scope and Approval`（共通）
- [references/output-contract.md](output-contract.md) — `## Validation Gates`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `### 7. Test Conversation, Work Sessions, and Holdouts`（new）
- [references/new-character-pack.md](new-character-pack.md) — `### 8. Compress after Calibration`（new）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 9. Test Beyond the Tuning Prompts`（revise）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 10. Compress, Finalize, and Approve`（revise）
- [assets/character-notes.md](../assets/character-notes.md) — `## Compression and Signal Density`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Validation Summary`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Workflow and Existing Context`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Calibration and Protected Traits`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Baseline and Selection Kernel`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Voice — Identity Invariants`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Voice — Distribution and Markers`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Association and Meme Response`（共通）
- [references/review-checklist.md](review-checklist.md) — `## State, Relationship, and Priority`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Source and Interpretation`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Evaluation Provenance`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Main Quality Tests`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Work-session Validation`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Required Diagnostics and Compression`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Dialogue Turn Boundaries`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Runtime Self-Containment`（共通）

**この段階の境界:** 実評価がある候補を対象に品質検証する。必要なユーザー対話が残ればその成果と照合点で応答を終える。

### 50-approval — bio・2色・対象版承認

本文・revision/hash・2色・検証条件・残る限界を見せ、その対象版への承認を受ける。既知の同一版承認は引き継ぐ。

- [references/output-contract.md](output-contract.md) — `## Calibration and Version Identity`（共通）
- [references/output-contract.md](output-contract.md) — `## Dialogue Turn Boundaries`（共通）
- [references/output-contract.md](output-contract.md) — `## Character Address Array — Authoring Confirmation`（共通）
- [references/output-contract.md](output-contract.md) — `## Completion, Provisional Delivery, and Waivers`（共通）
- [references/output-contract.md](output-contract.md) — `## Work-session Scope and Approval`（共通）
- [references/output-contract.md](output-contract.md) — `## Length`（共通）
- [references/output-contract.md](output-contract.md) — `## Source and Color Requirements`（共通）
- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Frontmatter Description Sources`（共通）
- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Visual Identity / Color Sources`（共通）
- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Separate Assets`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `### 9. Profile, Colors, and Final Review`（new）
- [assets/character-notes.md](../assets/character-notes.md) — `## Visual Identity / Color Notes`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Approval Record`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Asset / Rights Notes`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Format, Description, and Colors`（共通）
- [references/review-checklist.md](review-checklist.md) — `## Approval and Completion`（共通）

**この段階の境界:** 方向性への賛同と採用承認は別。承認前に色・子本文へ書き込まない。

## ファイル読込を補助する場合

登録先の参照機構で直接読む方法を標準とする。実ファイルが使える場合はSkillルートで次を使い、表示された全PARTを末尾まで読む。

```bash
python -B scripts/read_stage.py --stage 40-validation --kind new --part 1
```

改稿は`--kind revise`。ガイド内の次の段階も、同じ応答の仕事の範囲で読む。表示は原文取得の記録であり、実ユーザー評価や承認の代用ではない。
