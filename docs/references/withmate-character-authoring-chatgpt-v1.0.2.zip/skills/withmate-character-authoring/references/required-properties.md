# Required Properties — 欠落防止用authoring profile
Revision: skill-v1 / 2026-10-04

この文書は本Projectで生成する候補Packの共通構造の正本。人格・品質の内容は既存format/rubricを維持する。検査を曖昧にしないため、必須見出し・ラベルをこのProjectでは固定する。旧版で意味を保って統合された見出しは、本profileへの移行時に分離する。WithMate本体のparser一般についての主張ではない。

## MUST：全Characterで残すruntime項目
frontmatterはschema、name、descriptionの3キー。schemaの値はwithmate-character-v5。name/descriptionはJSON互換の二重引用符付き1行文字列（YAMLでも有効な部分集合）を使う。空文字・重複キー・追加キーを置かない。

10個のH2を次の名称で保持する。中身は空にせず固有の生成規則とする。
- Baseline Presence
- Identity Core
- Attention and Appraisal
- Social Intent / User Relationship
- Emotional Dynamics and Core Tensions
- Thinking and Action Style
- Voice Rules
- State Modulation
- Character Priority
- Minimal Reliability

Voice Rulesの直下に、Identity InvariantsとDistributional TendenciesのH3を保持し、以下の各ラベルを独立した `- ラベル: 値` で置く。内容を別欄に書いたつもりでラベルを消さない。

| H3 | 固定ラベル | 必要な内容（意味は人が検査） |
| --- | --- | --- |
| Identity Invariants | 一人称 | 正確な表記・明示場面・省略・状態差 |
| Identity Invariants | ユーザーの呼び方 | 任意の一人への基本呼称。場面・省略・頻度・語気 |
| Identity Invariants | ユーザーからの呼ばれ方 | 空でない文字列1件以上の重複なしJSON配列。順位・objectなし |
| Identity Invariants | 敬語度・表記 | 常体／敬体の基準、切り替え、重要な表記 |
| Distributional Tendencies | 文・テンポ | 長さ・間・切り方・長文時の変化 |
| Distributional Tendencies | 構文・語尾 | 採用する構文・語尾と働き |
| Distributional Tendencies | 語彙・表記 | 語彙・笑い・伸ばし等の平常と強弱 |

基本呼称と呼ばれ方は方向が逆。相互の代用は不可。未確定の必須項目はnotesでpendingとして追跡し、runtimeに空欄・placeholderを置いたままPack配布しない。設定事実の根拠と対話用の設計を分け、対象範囲と採否をsource-and-rights-policy.mdに従って扱う。低リスクな呼称・声の候補は既存policyの範囲で設計解釈として仮採用し、その根拠とユーザー確認状態をnotesへ残す。

対象の種類・資料の量にかかわらず上記構造を使う。対象の表現・版・時点、情報源の種別、観察と設計の違いは既存notesへ記録する。媒体分類や原作履修を必要とする管理欄をruntimeへ増やさない。descriptionは対象の一次根拠から作る短いプロフィールであり、公式bio専用ページの存在は必須条件ではない。

## CONDITIONAL / OPTIONAL：消せるものと条件
| 項目 | 扱い |
| --- | --- |
| Triggered Markers | 採用語がある時だけ必須。各語に6属性の内容を残す。未採用なら見出しを除き、notesへ理由 |
| habitual/reactive/signature | 全分類を埋める義務はない |
| Association and Meme Response | 該当Characterのみ。非該当理由はnotes |
| 補助呼称 | 採用する場合のみ。基本呼称は消さない |
| State Modulation内の状態 | 必要な状態を選ぶ。H2自体と変化／維持／復帰の役割は消さない |
| 作業中の規則と検証詳細 | conversation-and-workで必要。明示conversation-onlyなら非該当理由を記録 |

## MUST：notesの共通セクション
以下のH2は固定名を残す。未実施・不明・非該当は状態と理由を書き、空の見出し・空の表だけで埋めたことにしない。原テンプレートにあるそれ以外の補助見出しは必要に応じて使う。
- Target
- Workflow State
- Calibration Brief
- Likeness Anchors / Approved Traits
- Feedback and Revision Log
- Source Coverage Summary
- Evidence / Sources
- Frontmatter Description Notes
- Observation Log
- Derived Character Model
- Language Identity Analysis
- User Address Evidence
- Character Address Evidence
- Relationship Interpretation
- State Modulation Design
- Runtime Handoff
- Compression and Signal Density
- Conflicts / Uncertainty
- Visual Identity / Color Notes
- Validation Summary
- Approval Record
- Packaging
- Notion Sync Summary
- Asset / Rights Notes

作業用途ではH2 Work-session Design、およびValidation Summary配下のH3 Work-session Validation Recordも必要。conversation-onlyでは適用範囲にその値とユーザーの明示指定の根拠を残す。

Workflow Stateは既存ラベルのMode、Stage、Candidate revision、Candidate runtime SHA-256（LF正規化後のファイル全体）、Approval statusを埋める。呼ばれ方はCharacter Address Evidenceの `runtime採用配列（character.mdと同じ表記・並び）` と `配列の確認状態` を埋める。採用配列はruntimeと値・並びを一致させる。
Visual Identity / Color Notesの既存表でメインカラー／サブカラー各行に、大文字#RRGGBB、区分、出典・方法・根拠・不確実性を残す。Notion側の既存のその他propertyは勝手に追加・補完・上書きしない。

## MUST：案件の固定入力
Targetの `- Notion parent URL: 値` に、依頼で明示された事前作成済みキャラ親ページURLを残す。新規・改稿・provisionalにも必要。URL形式検査は構文だけで、キャラ親か、閲覧・編集可能か、依頼で指定されたかはconnector応答とユーザー発言で別確認する。同期不要でもURLの対象識別は維持する。親の作成はこの工程のactionにない。

## 機械検査と意味検査の分担

候補本文は `python -B scripts/validate_pack.py --runtime-only character.md` で単体検査する。notes、色、承認・同期記録を要求する完成Pack検査とは適用段階を分ける。配布前は従来どおり2ファイルPack全体を検査する。単体検査は候補を早く試すための形式確認であり、配布許可ではない。
validate_pack.pyはUTF-8/LF、Zip構成、frontmatter、固定見出し・ラベルの存在と非空、配列型・重複・notes一致、runtime上限、2色の形式、workflow記録の整合、runtime hash、Notion親URLの構文、記録された親actionに作成がないことを検査する。description160文字／notes256KiBは目安なので警告とする。

検査器はMarkdown/YAML全仕様のparserではなく、このauthoring profileのための狭い入力形式を扱う。見出しがコードフェンスやHTMLコメントにあるだけの場合は実体として数えない。必須役割の内容の十分さ、全notes項目の意味、語気・頻度の妥当性、marker6属性の意味、資料の真偽、承認の真正性、試験実行の事実、Notion結果は検査しない。機械検査passはGate A全体や完成判定を意味しない。

ルールの正本はこの文書。scripts/validation-contract.jsonは機械で扱う部分の対応物。変更時はJSON・検査器・テストも同時更新し、差分の整合を確認する。正式な製品実装では型定義から文書・schema・rendererを生成し、手作業の二重管理を減らす。

## MUST：runtime自己完結性と監査記録

内容の採否・肯定形による人物定義・必要十分性は`runtime-self-containment.md`を正とする。Character固有情報はfrontmatterを含むcharacter.mdで完結させる。モデル知識・外部原作・notesへの依存と、不採用語を名指しする禁止文は配布前に修正する。runtimeへ新しい監査欄や個別禁止語一覧は増設しない。

notesのRuntime Handoff直下にH3 `Runtime Closure Review`を置き、`- 対象runtime SHA-256: 値`、`- Review status: 値`、`- Review evidence: 値`を固定ラベルで記録する。statusはpass / fail / inconclusive / not-run。配布時はpassを要し、対象hashは実runtimeへ一致させ、evidenceに意味監査の箇所・結果・環境を追える参照を入れる。自己申告のpassを機械で認証したと表現しない。

Workflow StateのH3 Dialogue CheckpointsにD1/D2/D3の提示と実ユーザーの回答を対応させる。こちらは意味・真正性・時系列を会話で確認し、文字列があるだけでは通過させない。
