# Research and Alignment
Revision: skill-v1 / 2026-10-04

今回の成果は、調査に基づくキャラ像の照合案。正式設定の輪郭と、非公式の具体的な観察・受容・解釈を使って、平常の声・距離・選択を持ち込む。呼ばれ方は集合を提示して照合する。実際の候補出力への評価は次の工程で受ける。

現在の希望を引き継ぎ、問いを重要な1〜3論点に絞る。非公式資料は集約情報と個人の読みの両方を探す。具体的な仮説と読みの差を提示したら最終応答を終える。全runtime・全notes・全品質検証を準備する仕事へ拡大しない。

## 読む順序

以下は`read-plan.json`の同じ仕事に対応する原文範囲。新規はnew、改稿はreviseの項目を使い、共通項目は両方に適用する。同じ版の原文が現在の文脈に残っていれば重複表示を省く。未来の工程の資料を先読みして、その仕事まで実行する手順ではない。

### 00-start — 起動・対象固定

Skillの版・実行環境・最新notesを確認し、案件の親URLと既存版を固定する。仕様相談は個別キャラ工程に入らない。

- [references/workflow.md](workflow.md) — `全文`（共通）
- [references/output-contract.md](output-contract.md) — `## Dialogue Turn Boundaries`（共通）
- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Target Definition Scope`（共通）
- [references/output-contract.md](output-contract.md) — `## Scope`（共通）
- [references/output-contract.md](output-contract.md) — `## Workflow State — Canonical Definitions`（共通）
- [references/output-contract.md](output-contract.md) — `## Required Notion Parent URL`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `## Target / Inputs`（new）
- [references/new-character-pack.md](new-character-pack.md) — `## Output and Rules`（new）
- [references/improve-existing-character.md](improve-existing-character.md) — `## Input / Context`（revise）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 1. Preserve the Adopted Version`（revise）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 2. Read Feedback before Rewriting`（revise）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 3. Diagnose the Regression`（revise）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 4. Separate Preserve / Revise / Investigate`（revise）

**この段階の境界:** 親URL未指定ならその不足だけを伝える。読めない資料や既存版を取得済みにしない。

### 10-research — 初期調査

公式・一次設定で輪郭を確認し、非公式Wiki等と個人の感想・考察・公開コメントへ探索を広げる。声・距離・反応の具体的仮説と読みの差を用意し、実ユーザーとの照合へ返す。

- [references/runtime-self-containment.md](runtime-self-containment.md) — `全文`（共通）
- [references/runtime-philosophy.md](runtime-philosophy.md) — `全文`（共通）
- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `全文`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `### 1. Read Context and Research`（new）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 5. Expand Relevant Research`（revise）

**この段階の境界:** 調査だけで声が検証済みとはしない。初回は次のalignmentの成果を返して実ユーザー照合へ。

### 20-alignment — キャラ像・呼ばれ方の照合

一次設定と非公式の具体的な観察・解釈からBaseline・Anchors・呼ばれ方候補・作業中の存在感を提示し、実ユーザーと重要な1〜3論点を照合する。

- [references/source-and-rights-policy.md](source-and-rights-policy.md) — `## Evidence to Interpretation`（共通）
- [references/output-contract.md](output-contract.md) — `## Calibration and Version Identity`（共通）
- [references/output-contract.md](output-contract.md) — `## Dialogue Turn Boundaries`（共通）
- [references/output-contract.md](output-contract.md) — `## Character Address Array — Authoring Confirmation`（共通）
- [references/new-character-pack.md](new-character-pack.md) — `### 2. Bring a Calibration Brief`（new）
- [references/improve-existing-character.md](improve-existing-character.md) — `## 6. Align the Revised Character Image`（revise）
- [assets/character-notes.md](../assets/character-notes.md) — `## Target`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Workflow State`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Calibration Brief`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## User Input Classification`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Likeness Anchors / Approved Traits`（共通）
- [assets/character-notes.md](../assets/character-notes.md) — `## Character Address Evidence`（共通）

**この段階の境界:** D1未達なら仮説・呼ばれ方配列・照合点を返して最終応答を終える。全Pack・全検証・色確定へ先回りしない。対象の版・時点だけはD1通過の根拠ではない。

## ファイル読込を補助する場合

登録先の参照機構で直接読む方法を標準とする。実ファイルが使える場合はSkillルートで次を使い、表示された全PARTを末尾まで読む。

```bash
python -B scripts/read_stage.py --stage 00-start --kind new --part 1
```

改稿は`--kind revise`。ガイド内の次の段階も、同じ応答の仕事の範囲で読む。表示は原文取得の記録であり、実ユーザー評価や承認の代用ではない。
