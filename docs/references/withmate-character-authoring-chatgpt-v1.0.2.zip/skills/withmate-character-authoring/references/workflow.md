# Workflow — 今回の応答を定める
Revision: skill-v1 / 2026-10-04

## Scope

このSkillはWithMate V5 CharacterPackの対話型作成・改稿に使う。仕様相談、資料監査、Skill自体の改修は依頼された資料を返す別の仕事であり、個別Characterの作成・Notion同期へ移らない。

## Start and Resume

現在の実ユーザー入力、同一案件の最新notes、既に提示した候補と実評価を読む。新規は`new`、既存版の改稿は`revise`。キャラ案件は事前作成済みNotion親URL1件で対象を固定し、同一案件の会話中は再利用する。URL不足なら対象の指定を求めて返す。リンクの取得は利用可能な対応connectorで行う。

前回の「実ユーザー入力を待つ理由」を確認し、実際に届いた返答を照合する。対象の版・時点・ネタバレ範囲・関係性の指定は照合案の材料。設定指定、D1のキャラ像照合、D2の候補出力評価、D3の対象版採用を別に記録する。記録と実際の発言に差があれば実際の発言へ戻る。

## Current Reply

| 応答の仕事 | 入る条件 | この応答で返す成果 | 返した後 |
| --- | --- | --- | --- |
| alignment | 新規の初回、またはキャラ像の再照合が必要 | 調査した声・距離・重要特徴、呼ばれ方候補配列、重要な1〜3論点 | 応答を終え、次の実ユーザー入力へ |
| calibration | D1後の候補作成・修正・再試演 | 保存・検査した同一候補の未編集試演と照合点 | 応答を終え、その出力への評価を受ける |
| validation | 提示済み候補への実評価があり主要な違和感が解消 | 実施した品質検証、本文・revision/hash・2色・限界 | 必要な対話／同一版への採用承認を受ける |
| delivery | 提示済み同一版の実採用承認、または対象版への明示override | 条件を満たす同期、最終2ファイルZip、実行結果 | 同期と品質の状態を区別して報告 |

仕事は応答開始時に一つ選ぶ。調査完了、途中報告の質問、試演の生成を根拠に、同じ応答で次の仕事を開始しない。ユーザーへ返す質問・試演は最終応答の成果とし、その後に実ユーザーの返答が届いてから再開する。新規初回は照合案を完成させる仕事であり、全Packの制作依頼へ展開しない。

既に確認した同じ内容は引き継ぐ。通常の「続けて」「おまかせ」、詳しい関係指定、ネタバレ許可は対話省略を表さない。明示的な「確認を省略して一度で作成」だけをone-shotの別経路とし、provisional / waivedを記録する。途中試用と対象版への書込overrideは、それぞれ明示された範囲に限る。詳細は[Output Contract](output-contract.md)を使う。

## Stage Reads

入口は[SKILL.md](../SKILL.md)。初回・再開は現在の仕事のガイドを一つ開く。ガイドに並ぶ該当原文を読み、同じ版の既読原文が現在の文脈に残っていれば重複読込を省く。

- alignment: [research.md](research.md)
- calibration: [drafting.md](drafting.md)
- validation: [validation.md](validation.md)
- delivery: [deployment.md](deployment.md)

工程別の読込範囲は[read-plan.json](read-plan.json)に対応する。登録先の参照機構で直接読む方法を標準とし、実在するSkillディレクトリとPythonがある場合は`scripts/read_stage.py`で同じ原文を分割表示できる。manifest照合は同梱ファイルの一致確認であり、理解・承認・品質の証明ではない。

## State and Work Files

案件状態は`character-notes.md`の既存Workflow State / Dialogue Checkpointsへ差分記録する。記録するのは提示対象、受け取った実発言、次の仕事、未解決点。新規の状態用サーバーや、モデルが自由に書ける承認フラグを信頼境界として追加しない。

候補、notes、ログ、最終PackはSkillディレクトリの外に保存する。同梱雛形は原本として読み、案件別コピーを編集する。標準の配布物は`character.md`と`character-notes.md`だけ。Skill内の管理資料と検査用データは配布用CharacterPackから分離する。
