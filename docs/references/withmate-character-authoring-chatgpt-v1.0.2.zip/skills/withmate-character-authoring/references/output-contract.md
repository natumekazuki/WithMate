# Output Contract

Authoring revision: skill-v1 / 2026-10-04

## Scope

この契約はCharacterPackの作成・改稿・試作配布・確定・同期を扱う。project定義更新の依頼は別であり、ユーザーが反映するための内部資料一式を渡す。project更新だけでは個別CharacterやNotionのCharactersデータベースを書き換えない。

本契約の構造・対話・承認・同期条件は、キャラクターとして定義する対象全般へ適用する。対象の定義範囲と資料の採否はsource-and-rights-policy.mdの共通手順を使い、資料の種類や不足を理由に別の完成経路へ変更しない。

## Standard CharacterPack Deliverable

```text
CharacterPack root/
  character.md
  character-notes.md
```

新規・改稿・試作を問わず、この2ファイルだけをZip直下へ入れる。CharacterごとのREADME、source report、review checklist、manifest、assets directoryは作成・同梱しない。内部の作業記録や検証用の一時ファイルを使った場合も配布しない。

画像等は明示依頼がある場合のみ別添。標準Packへ混在させない。試作の状態、対象版、既知の弱点はnotesと受け渡しメッセージで示し、runtimeへ管理用の注意書きを足さない。

## Workflow State — Canonical Definitions

標準modeは`collaborative`。ユーザーが確認省略・一括作成を明示した場合のみ`one-shot`にする。作成のコスト削減を理由に自動でone-shotへ切り替えない。

| Stage | 意味 | 次に進む条件 |
| --- | --- | --- |
| research | 既存の希望と資料を確認し初期調査 | キャラ像の仮説・重要な不確実性を提示できる |
| alignment | ユーザーと対象persona・声・距離・重要特徴を照合 | 残す特徴と未確定点が追跡でき、試作の方向が合っている |
| calibration | 候補定義、未編集の試し会話、フィードバック、原因修正 | 重要な違和感の対応が済み、検証する版が定まる |
| validation | 通常出力、holdout、継続対話、対象用途の作業セッション、形式等を検証 | 必須品質項目がpassし、環境上の未検証事項は開示済み |
| awaiting-approval | 対象版、変更点、検証範囲を提示して確定を確認 | ユーザーがその版を明示的に採用する |
| approved | ユーザー確認済みの確定版 | 配布と、条件を満たすNotion同期へ進める |
| provisional | 確認省略または未検証事項を残す試用版 | 通常の承認フローへ戻るか、明示的な例外指示で配布・反映する |

段階は必要に応じて戻れる。同一ターンで進められるのは、その工程に必要な実ユーザー確認・候補への評価が既に存在する範囲に限る。未回答の照合点を作成者が勝手に承認しない。質問の提示だけでは回答の取得にならず、試演の生成だけでは実ユーザー評価の取得にならない。未取得なら成果と確認点を返してそのターンを終える。ユーザーと実際に往復する工程は、この場で成果と確認点を示して返す。非同期の作業や後日の自動完了を約束しない。

## Dialogue Turn Boundaries

作成依頼は対話セッションの開始依頼として扱う。各応答の仕事は、開始時点の実ユーザー入力から選ぶ次の一種類である。対象指定と工程の通過は別であり、表現・版・時点・関係性・情報の開示範囲・親URLは対象条件として引き継ぐ。

| 今回の仕事 | 開始時の条件 | 今回の成果と終了点 |
| --- | --- | --- |
| キャラ像照合 | 新規案件の初回、または声・距離・重要特徴の再照合が必要 | 初期調査から、平常の声・距離・重要特徴・呼ばれ方候補配列・重要な1〜3論点を提示して最終応答を終える |
| 試演・調整 | キャラ像の照合後、候補出力の評価または修正・再試演が必要 | 候補本文を保存・構造検査し、その版の未編集試演と評価点を提示して最終応答を終える |
| 検証・承認照合 | 実ユーザーが見た候補への評価があり、主要な違和感が解消 | 通常・継続・未見・作業等の実施可能な検証を行い、対象本文・revision/hash・2色・検証範囲を提示して最終応答を終える。対話による検証は必要な回に分ける |
| 確定・同期 | 開始時点で提示済みの同一対象版への採用承認がある | 同じ本文を確定し、指定親への同期・最終2ファイルZipの照合を行って結果を返す |

新規案件の初回成果はキャラ像照合である。詳しい初期指定は照合案の材料として使う。既存の同一案件の対話を再開する場合は、記録された照合・評価を引き継いで今回の仕事を選ぶ。通常の「続けて」は現在の仕事の続きを指す。

応答中に調査が完了したことや、質問・試演を提示したことによって今回の仕事を後段へ変更しない。完了条件は「今回の成果を返すこと」であり「全Packを作ること」ではない。質問は最終応答に置き、その後のユーザー発言を受けて次の仕事を開始する。これにより、単なる工程表の提示と実際の対話を区別する。

D1はキャラ像の実照合、D2は提示した候補出力への実ユーザー評価、D3は提示した同一版への採用承認を表す。既存のWorkflow State / Dialogue Checkpointsに提示と回答を対応させ、既知の同一内容の確認を引き継ぐ。参照を得られない場合は日時と短い実発言を記録する。ユーザーが見ていない未来版、作成者の自己採点、scriptedな応酬は実ユーザー評価の代用にしない。

肯定評価の後は必要な検証へ、違和感の指摘後はその原因を修正した別入力での再試演へ進む。声・距離を変えた新版の評価を旧版から自動移転しない。対象版への承認済み発言があれば同じ承認は取り直さない。

明示的な対話省略・一度での作成指定はone-shotの別経路として記録する。provisionalは品質・承認の状態であり、対話を省略する権限ではない。途中試用の明示依頼は、その時点の候補を試用目的で渡す許可として扱い、後段の完了には読み替えない。

## Calibration and Version Identity

`character-notes.md`のWorkflow Stateに次を記録する。

- Mode、Stage、候補revision（例：r01）、現在の候補、現在採用されている版。
- LF正規化後の`character.md`全体のSHA-256。計測できない場合は`not-measured`と理由を書き、revisionと本文照合で区別する。
- キャラ像の照合状態、未解決の論点、次に必要な評価。
- 呼ばれ方配列の確認状態（pending / confirmed / waived）と、Character Address Evidenceの対象配列・確認記録への参照。
- Approval status: `not-requested / pending / approved / waived`。
- 対象revision、runtime hash、確認日時、確認の根拠となる会話の参照または短い記録。
- 検証環境の範囲と、未検証の重要項目。

- 利用範囲: `conversation-and-work`（標準）/ `conversation-only`（明示指定）。対象タスク、作業検証の適用理由・証拠範囲・未実行の実作業。

hashはruntime本文の識別用。notes自身のhashをnotesに入れる再帰的な管理は行わない。

ユーザーの「方向性はよい」はalignmentの確認になり得るが、未提示のruntime最終版への承認ではない。出力評価後に対象版を「これで確定」と指定した場合は、同じ確認を繰り返さず承認として扱う。曖昧な返事で未確認の重大変更を採用しない。

承認後にruntime本文やdescriptionを変える場合は新revisionを作り、変更の影響を再検証して再承認する。同期結果、file計測値等のnotesだけの事務的追記ではruntime承認を取り直さない。色の承認対象値もnotesへ保持し、勝手に別値へ変更しない。

## Character Address Array — Authoring Confirmation

新規・改稿とも、researchで設定上の名前・公開名・略称・愛称と既知のユーザー希望を確認し、alignmentまたはcalibrationで「ユーザーからの呼ばれ方」の候補をフラットな文字列配列として提示する。基本・既定・優先は設けず、集合全体の追加・削除・表記をユーザーと確認する。他の照合点とまとめ、呼称を1件選ばせる質問や確認だけの不要な往復を増やさない。

確認した配列、日時、会話参照、出典・設計上の解釈、採否をnotesのCharacter Address Evidenceへ記録し、Workflow Stateから参照する。対象の配列について明示的な指定・確認が既にあれば引き継ぎ、同じ内容を聞き直さない。未回答や一般的なキャラ像への賛同を、配列の確認済みへ置き換えない。

配列の追加・削除・表記変更は変更後の集合を提示して確認する。列挙順は順位ではなく、順番だけの変更に独立した呼称確認は要らない。ただしruntime本文が変わった場合のrevision/hashと最終承認は既存の規則に従う。配列の確認は最終runtime承認の代わりではないが、配列を明示した同じ対象版への承認で両方を確認できる。

確認前の試作では候補配列を仮採用できるが、配列の確認状態はpendingのままにする。標準完成では採用配列がconfirmedであることを必要とし、未確認の配布はprovisional。明示的なone-shotで未確認の配列を採用する場合は、呼ばれ方配列の確認をwaived、Stageをprovisional、Approvalをwaivedとして、根拠と未確認を残す。既に確認済みの配列はconfirmedを維持する。

## Completion, Provisional Delivery, and Waivers

標準の完成は、合意した重要特徴が通常出力・連続会話・対象用途の作業セッションで確認され、必要な検証と対象版へのユーザー承認が揃った状態。総合点や作成者の満足だけでは確定しない。会話専用の明示指定では作業検証の非該当理由を残す。

必須品質testの`fail / inconclusive / not-run`を残した配布は`provisional`。事実・権利・安全・schema・必須構造・runtime自己完結性・2ファイル構成は例外指示でも無視しない。

provisionalという状態名だけで配布を始めない。未承認の試用Packを配布できるのは、ユーザーがその時点の試用を明示要求した場合、明示one-shotの場合、またはD1/D2を経たD3の承認用候補として提示する場合。一般的な「作成して」から初回に自動でprovisional Packを渡さない。D1前の例外試用が明示要求されても、それを標準工程完了とはせず記録する。

ツールや検証環境が使えない場合も、利用可能な調査・設計・試演の成果は返す。ただし現在のDialogue Turn Boundariesを越えず、実ユーザーの次の入力が必要ならそこで応答を終える。環境不足はone-shotへの変更理由、対話checkpointの免除、自己完結性の欠測を配布する理由にならない。

明示的なone-shotでは可能な検証を行って2ファイルを渡し、Approvalは`waived`、Stageは`provisional`とする。「質問なしで作成」は、未承認草稿を既存の採用版へ上書きする許可ではない。

ユーザーが未承認・未検証の対象版を承知したうえで「この版をそのままNotionへ反映」と指示した場合は、例外の書き込みを行える。対象版、未達項目、明示指示、`deployment_override`をnotesへ記録し、Stageをapprovedに偽装しない。

WithMate実機が使えないことだけで永久に承認待ちにしない。主品質testは利用可能な環境で行い、環境を明示する。独立環境または実機で未検証の範囲を理解したユーザーは、その範囲に限定して候補を承認できる。実機で検証したとは記録しない。

## Work-session Scope and Approval

WithMateの標準用途は`conversation-and-work`とし、会話と、コーディング・調査・編集等の実作業の往復を対象にする。用途は既存の依頼から引き継ぐ。会話専用の明示指定時だけ`conversation-only`とし、作業testを`not-applicable`にできる。環境が使えないことや、作成側の都合は非該当理由にしない。

対象用途には`Task-execution / Conversation-work Continuity`を必須主品質testとして追加する。順調な作業と想定外を含む作業、作業中盤、ユーザーの割り込み、完了または中止から会話への復帰を、時間順に検証する。個々の事件の発生や毎操作の発話をノルマにしない。手順と評価軸は`authoring-rubric.md`を正とする。

実行環境と作業イベントの出所は別軸。`synthetic-event`（架空の出来事）、`recorded-tool-replay`（保存済み実ログの再生）、`live-tool-execution`（候補が実際にtoolを使う実行）をイベントごとに識別する。環境がWithMateでも、提示したエラーが架空なら実作業成功の証拠にはならない。

利用可能な範囲では、安全な検証用課題を候補に実行させる。実行環境がない時も、時間順のイベントによる反応・状態整合・会話との往復を検証できる。その場合のpassは提示イベントへの反応に限定し、実際の編集・実行・機能検証は`not-run`のまま別記する。作業test全体を未実施のまま合格へ変更しない。

承認には、対象タスク、実行環境、イベント出所、実作業で確認した範囲、未確認の注入・表示条件を含める。必須の反応・継続性testを確認したうえで、実作業やWithMate未検証を理解したユーザーはその限定範囲で承認できる。すでに確認した品質のfailを未検証環境という理由で免除しない。実行能力まで実証済みとは表示しない。

作業中の声を直してruntimeを変更したら新revisionとし、会話・作業の両方で影響を再確認する。本文が変わらず検証結果だけを追記する場合はhashを維持し、承認範囲を広げる時だけ追加の確認を記録する。

## Language and Runtime Contents

`character.md`本文は日本語。frontmatterは`schema: withmate-character-v5`、name、descriptionを必須とする。descriptionは本人の短いプロフィールで、1〜3文・160文字以内を目安にする。公式bioを優先し、対象の一次設定・創作者設定からの要約もsource-and-rights-policy.mdの共通手順で扱う。

必須の役割はBaseline Presence、Identity Core、Attention and Appraisal、Social Intent / User Relationship、Emotional Dynamics and Core Tensions、Thinking and Action Style、Voice Rules、State Modulation、Character Priority、Minimal Reliability。Voice Rulesに一人称・任意の一人への基本呼称と表記、使用場面、省略、頻度、語気を含める。これとは別に、Identity Invariantsへ「ユーザーからの呼ばれ方」を必須の文字列配列として置く。基本・優先や要素ごとの属性は持たせず、詳細は`withmate-v5-character-format.md`に従う。

短い特徴ラベル、語尾、採用した口癖、未完成の構文型は残せる。完成返答Examples、場面別台詞集、試し会話の回答はruntimeへ入れない。内輪の固有名や不採用語を否定文で再掲しない。固有情報はファイル内で完結させ、必要な情報は意味・関係・現在の状態まで、不要な情報は名称・暗示・禁止文ごと除く。モデル知識による補完を前提にしない。詳細は`withmate-v5-character-format.md`と`runtime-self-containment.md`に従う。

## Length

- `character.md`全体をLF正規化し8,000文字以内。frontmatter、Markdown記号、空白、末尾改行を含む。
- 最低文字数、推奨目標帯、上限へ近づける目標は設けない。声と関係の校正後に必要十分な量へ整理する。
- 文字数・bytes・token数は別物。token数を計測できなければ推定を実測値として書かない。
- `character-notes.md`は256 KiB以内を目安に、再開・検証・採否を追える形で整理する。

## Notes Required Content

Target、Workflow State、Calibration Brief、Likeness Anchors、Feedback and Revision Log、source一覧と確認範囲、descriptionの根拠、Observation Log、Derived Character Model、Language Identity Analysis、User Address Evidence、Character Address Evidence、relationship、state、runtime採否、圧縮前後、未確認と媒体差、色、Validation Summary、Approval Record、Notion Sync Summary、rightsを含める。

依頼者の観察／希望／出力評価／創作者定義と、外部の読者・視聴者の観察／受容／解釈を区別する。一次設定・直接観察・第三者の記述・対話用設計は根拠IDで追跡し、外部の好評を依頼者の候補評価・承認の代わりにはしない。確認済みの特徴を改稿の退行検査に使う。テスト原出力は実在する会話参照や保存先を示し、保存不能は明示する。同じ記録の全文転記はまとめて参照する。

作業用途ではWork-session DesignとWork-session Validation Recordを含める。タスク・初期状態・受入条件、イベントと未編集の途中発話の対応、3評価軸、機能検証、ユーザー評価、注入・表示範囲を記録する。非公開コードや秘密情報をnotesへ転載せず、必要箇所の最小抜粋と参照を使う。参照先が利用不能なら再現性の限界を残す。

## Source and Color Requirements

source-and-rights-policy.mdに従い、公式・一次設定で輪郭を定め、非公式Wiki等の集約資料と個人の感想・考察・公開コメントへ探索を広げて、らしさの詳細を組み立てる。非公式は主要な解釈資料として扱い、具体性・文脈・独立性・対象適合性で評価する。関連資料の探索範囲・不足理由、設定事実／観察／受容・解釈／設計を既存notesに残す。全特徴の一次照合や資料の豊富さを、実ユーザーとの照合・試演・修正の代わりにはしない。リンク取得と、本文・画像・音声・映像の確認を区別する。

メイン・サブをsRGBの大文字6桁`#RRGGBB`で決める。正確な公式コード、公式明示色、公式ビジュアル近似、作成上の解釈の順に優先する。`official-published / official-sampled / authoring-derived`、source、確認日、方法、理由、信頼度、不確実性を記録する。肌、影、背景、透過、圧縮ノイズを代表色にしない。色はnotesとNotion propertyのみ。

## Validation Gates

`review-checklist.md`と`authoring-rubric.md`で、形式・source・権利・品質・承認・配布を分けて確認する。runtime自己完結性はGate Aの配布条件とし、`runtime-self-containment.md`の参照監査を実施する。構造検査の成功だけで意味検査passとしない。

呼ばれ方は、配列形式とnotesとの一致、ユーザーによる集合の確認、呼びかけの認識を分けて確認する。認識確認は既存の会話・作業testへ組み込み、呼称の入力を口癖の自然発火の証拠には数えない。

主品質testは、通常生成のBaseline/Anchor、Voice-restoration、Marker-underuseとMarker-overuse、未見3入力以上、同義3入力、Core-tension、長い説明、7場面relationship、継続対話。

作業用途ではTask-execution / Conversation-work Continuityも必須。Work Likeness、Task Integrity、Collaboration Comfortを別々に評価し、一軸の良さで他軸の未達を相殺しない。

Name-swapとPhrase-suppressionは必須の診断であり、それだけで自然な出力品質を合格としない。

未実施は`not-run`、根拠不足は`inconclusive`。markerが0回というだけで適切とも不適切とも判断しない。出現機会と不要な文脈を分ける。調整に使った入力はholdoutから外す。生成後に手直しした作例を未編集の検証結果と偽らない。

## Required Notion Parent URL

CharacterPackの新規作成・改稿・別会話での再開では、ユーザーが事前作成したキャラ単位の親ページURLを、その依頼に1件明示する。データベース一覧・ビューのURLだけでは対象の指定にならない。同一会話で同一案件の対話を続ける間は指定済みURLを固定して使い、毎ターン貼り直しを求めない。仕様相談・Project更新には不要。この必須入力は同期不要の依頼でも対象識別のため維持する。

URL未指定ならその不足だけを伝えて対象指定を受ける。名前検索、過去の別案件のリンク、似たページから対象を推測しない。URLが読めない場合は実際の接続エラーと取得できない既存情報を記録し、手元の資料で可能な調査・校正まで進められるが、未取得の採用版や承認を推測しない。Notion書き込みは停止する。

対応connectorが受け付ける形式で指定URL／page IDを直接取得し、対象キャラの親であることを確認する。Charactersデータベース全体の列挙、親の名前検索、0件判定後の親作成、親のdefault template適用は実行しない。親ページ、Name、会話URL、色以外のpropertyはユーザー管理とする。既存の2色propertyと必要なschemaを取得し、property不足・型不一致なら推測で増設せず同期を停止する。

取得したpage ID、親URL、親直下の対象子URL／ID、既存本文・取得時点をnotesへ記録する。frontmatterのnameと取得したNameはNFC・trim後完全一致で安全照合するが、対象探索には使わない。不一致は自動改名せず解消を求める。親URLの指定は候補本文への採用承認でもdeployment_overrideでもない。

## Notion Handoff — Write Gate

接続が利用でき、同期不要の指定がない場合、承認済みの対象版をユーザー指定済みの既存親ページへ同期する。調査のためのreadは承認前でも行える。親は事前作成済みで、作成工程では新設しない。

草稿・試作・承認待ちは既存の採用版を上書きしない。色propertyの更新にも同じgateを適用する。親ページの作成はこの工程には含めない。承認待ちを接続失敗と混同せず、Statusは`pending`、理由は`approval-required`等と記録する。

例外は、対象版への明示的な`deployment_override`だけ。project定義の更新依頼、初期の一般的な同期希望、確認省略だけをoverrideにしない。

## Notion Synchronization Procedure

1. 承認／明示overrideの対象revision・runtime hash・2色とローカル最終版を照合する。ユーザー指定URLから取得した親page IDを固定し、異なる親や名前検索へ切り替えない。
2. 書込直前に指定親と対象子を再取得する。調査時点からの本文・更新情報の差を確認し、別の更新を無断で上書きしない。frontmatterのnameと取得したNameをNFC・trim後完全一致で安全照合する。URLの構文検査だけで実在・親子関係・権限を確認したことにしない。
3. 親直下の子をpaginationを含めて列挙し、取得タイトル`character.md`、`character-notes.md`の完全一致をそれぞれ確認する。各1件ならその子を使う。0件ならwrite gate通過後にだけ作成できる。2件以上なら同期を停止する。似たタイトルを勝手に改名・削除しない。既知の子IDも同じ親に所属することを確認する。
4. 子が存在しない場合、同じ親直下を作成直前に再確認し、既に作られていれば再利用する。作成できたURL／IDを保存し、再試行で同じ子を増やさない。親の作成・template適用・Nameや会話URLの設定は行わない。
5. 親は既存のメインカラー・サブカラーの2propertyのみ更新する。ほかのpropertyと親本文を保持する。対象の色や子本文が完全一致ならその更新を省けるが、存在・一意性・同一性の確認は省かない。tool/APIに原子的な競合制御がない場合、再取得だけでは競合を完全に防げない限界を記録する。
6. 各子はファイル全文を単一の`markdown`コードブロックに保持する。実際のtool schema・上限に従う。rich textの複数要素を一つのcode block内へ格納できる場合は全文の連結一致を確認する。制約上全文を保持できなければpending/failedとし、黙って切り捨てたり複数code blockへ変更しない。無関係な既存ブロックがある場合は、その削除許可を推測しない。
7. 親・両子を再取得し、指定親の同一性、子の一意性、HEX、単一コードブロック、全文の一致、保護対象propertyを照合する。Markdown表示ではなくコードブロックの実テキストを比較する。比較で正規化する場合はLFのみとし、空白や語句の差を隠さない。
8. 実施済みactionを親`updated / unchanged / not-run`、子`created / updated / unchanged / not-run`としてURL・日時・結果と共にローカルnotesへ記録する。ここまでの照合成功と、これから行う最終notesの照合を区別する。
9. 記録を反映した最終notesを再同期し、再取得してローカル最終notesと照合する。最後の照合結果は受け渡し回答にも残す。成功確認後に「確認した」とnotesをまた書き換える再帰ループを作らない。notesに最終照合の未来の成功日時を先書きしない。追加変更が本当に必要なら照合をやり直す。
10. 途中失敗では既知のURL、完了action、未完部分を残し、部分成功を全体syncedとしない。最終照合に失敗したらローカルnotesにも失敗を反映し、Notionとの不一致を明示する。再試行は既存IDを使う。Notion失敗とCharacter品質を混同せず、可能なローカルPackを渡す。
11. 最終notesを含むローカル2ファイルをパッケージする。Zipのroot2ファイル・階層・最終原稿とのbyte一致を検査する。検査対象をそのまま渡し、最後の文章整形でruntimeを別物にしない。Statusは`synced / pending / skipped / failed`と理由で管理する。

## Packaging Validation

Zipのrootファイル名が`character.md`と`character-notes.md`の2件だけで、余分なfile、directory、旧版がないことを確認する。展開後の各本文を元ファイルとbyte比較する。最終notesの更新で古いZipになった場合は作り直す。

記録するのは実測した件数、名前、階層、照合範囲、確認日。自分自身の最終hashをnotesへ埋める必要はない。Notion再取得・Zip再生成の後に内容が変わった場合は該当照合をやり直す。

## Efficiency Without Quality Loss

削減するのは重複探索・転記・不要な書込・無目的な再生成であり、Character品質の判定条件ではない。

- 読む順と範囲はSkill内の`references/read-plan.json`を正本とし、工程別ガイドから該当原文を読む。初回／再開時はSkillの版と最新notesを確認する。登録済みSkillの参照機構または実在するSkillファイルを使い、Source Zipの探索・展開を起動条件にしない。同じ版の本文が現在の文脈に明確に残っている場合だけ再表示を省ける。ハッシュ一致・ファイルopen・読込receiptは、モデルが意味を理解した証明ではない。記憶や短い要約だけでは未読原文を代用しない。
- 新規と改稿は共通の状態遷移を使う。改稿だけ既存版保存・既知の評価・Preserve/Revise/Investigate・退行診断を加える。両方の手順を二重に最初から実行しない。
- notesは判断の正本へ一度記録してID／節を参照し、同じsourceやユーザー発言を複数の表へ全文転記しない。必須見出し・必要な根拠は残し、未実施は状態と理由を書く。各ターンは変化した状態・フィードバック・差分だけを更新する。未確認事項を空の表で完了扱いしない。
- 既取得の対象時期の原作本文や確認済み合意は再利用する。現行bio・所属・公開状態等の時点依存情報、競合・欠測・対象時期変更は必要な追加調査を行う。Source Policyの適用条件に沿った根拠の確認と、確認できた材料の区別を保つ。
- 同一revision/hash・同じ環境の未編集ログは、成立する複数testの証拠として共用できる。各testの出現機会・入力条件・判定は独立に記録する。未見3入力・同義3入力・7場面・継続対話・作業往復・必須診断は削らない。調整用と未見、自然markerと呼称明示、通常版と抑制版を混ぜない。短い1件を全testのpassへ流用しない。
- A/Bは比較する解釈がある時に使い、全Characterで多案を作る義務にしない。重要な出力への実ユーザー評価は省かない。
- 色の調査は必要なビジュアル確認時に行い、採用した2色をむやみに再選定しない。標準の最終承認と同時に確認できる。途中Packを配る場合も、先にGate Aの2色等を満たす。
- runtimeは合意した特徴を修正する差分中心で編集する。8,000文字以内で重複・害のある競合がなければ、短くするだけの全面書換をしない。圧縮／ablationを省いた場合は理由と未実施を残し、効果なしとはしない。Name-swapとPhrase-suppressionは必須診断のまま維持する。
- 候補本文と2色を確定し必要な検証後に承認を得る。承認後のruntimeの書き直し・見た目だけの整形でも本文が変われば新revision/hashと必要な再検証・承認が必要。notesの事務的追記と別扱いにする。
