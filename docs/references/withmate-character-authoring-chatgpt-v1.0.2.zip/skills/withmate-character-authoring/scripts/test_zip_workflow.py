"""Local structural / source-loader tests, not model-behavior or Notion tests."""
from pathlib import Path
import contextlib
import io
import json
import shutil
import tempfile
import unittest
from read_stage import ROOT, verify, spans, source_range, chunks, paginate, main, safe_path
from validate_pack import Validator, notion_parent_id
from test_validate_pack import CONTRACT, fixture

ID='0123456789abcdef0123456789abcdef'
URL='https://www.notion.so/'+ID

class URLTests(unittest.TestCase):
    def codes(self,data): return {e['code'] for e in Validator(CONTRACT).validate(data)['errors']}
    def notes(self,old,new):
        data=fixture();data['character-notes.md']=data['character-notes.md'].decode().replace(old,new).encode();return data
    def test_notion_standard(self): self.assertEqual(notion_parent_id(URL),ID)
    def test_notion_app(self): self.assertEqual(notion_parent_id('https://app.notion.com/p/workspace/'+ID+'?source=copy_link'),ID)
    def test_notion_hyphen_id(self): self.assertEqual(notion_parent_id('https://www.notion.so/01234567-89ab-cdef-0123-456789abcdef'),ID)
    def test_notion_public_slug(self): self.assertEqual(notion_parent_id('https://example.notion.site/Test-'+ID),ID)
    def test_notion_foreign(self): self.assertIsNone(notion_parent_id('https://example.com/'+ID))
    def test_notion_lookalike(self): self.assertIsNone(notion_parent_id('https://notion.so.example.com/'+ID))
    def test_notion_no_http(self): self.assertIsNone(notion_parent_id(URL.replace('https:','http:')))
    def test_notion_not_query_id(self): self.assertIsNone(notion_parent_id('https://www.notion.so/?v='+ID))
    def test_notion_no_credentials(self): self.assertIsNone(notion_parent_id(URL.replace('www.','user:pass@www.')))
    def test_notion_missing(self): self.assertIn('E_NOTION_PARENT_URL',self.codes(self.notes('- Notion parent URL: '+URL,'')))
    def test_notion_empty(self): self.assertIn('E_NOTION_PARENT_URL',self.codes(self.notes(URL,'')))
    def test_notion_created_disallowed(self): self.assertIn('E_NOTION_PARENT_ACTION',self.codes(self.notes('## Notion Sync Summary','## Notion Sync Summary\n\n- Parent action: created')))
    def test_notion_unchanged_allowed(self): self.assertNotIn('E_NOTION_PARENT_ACTION',self.codes(self.notes('## Notion Sync Summary','## Notion Sync Summary\n\n- Parent action: unchanged')))
    def test_syntax_success_not_release(self): self.assertFalse(Validator(CONTRACT).validate(fixture())['release_authorized'])

class ReaderTests(unittest.TestCase):
    def copy_bundle(self,base):
        root=Path(base)/'bundle';shutil.copytree(ROOT,root);return root
    def test_manifest_integrity(self): self.assertEqual(verify(ROOT)['revision'],'skill-v1')
    def test_every_plan_range_and_kind(self):
        plan=json.loads((ROOT/'references/read-plan.json').read_text())
        for stage in plan['stages']:
            for kind in ['new','revise']:
                expected=''
                for entry in stage['reads']:
                    if entry.get('kind',kind)==kind:
                        lines,a,b=source_range(ROOT,entry);expected+=''.join(lines[a:b])
                actual=chunks(ROOT,stage,kind,4500)
                self.assertEqual(''.join(x[3] for x in actual),expected)
                self.assertEqual([x for p in paginate(actual,4800) for x in p],actual)
                self.assertTrue(all(len(x[3])<=4500 for x in actual))
    def test_fenced_heading_is_not_match(self):
        self.assertEqual([x[1] for x in spans('# real\n```md\n# fake\n```\n## real2\n')],['# real','## real2'])
    def test_tilde_fence(self):
        self.assertEqual([x[1] for x in spans('~~~\n# fake\n~~~\n# real\n')],['# real'])
    def test_duplicate_heading_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);(p/'a.md').write_text('# Same\nx\n# Same\ny\n')
            with self.assertRaises(ValueError):source_range(p,{'path':'a.md','heading':'# Same'})
    def test_missing_heading_rejected(self):
        with self.assertRaises(ValueError):source_range(ROOT,{'path':'references/workflow.md','heading':'# not-here'})
    def test_hash_change_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=self.copy_bundle(temp);f=p/'references/runtime-philosophy.md';f.write_bytes(f.read_bytes()+b'\n')
            with self.assertRaises(ValueError):verify(p)
    def test_extra_file_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=self.copy_bundle(temp);(p/'extra.txt').write_text('extra')
            with self.assertRaises(ValueError):verify(p)
    def test_missing_file_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=self.copy_bundle(temp);(p/'assets/character.md').unlink()
            with self.assertRaises(ValueError):verify(p)
    def test_extra_directory_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=self.copy_bundle(temp);(p/'empty').mkdir()
            with self.assertRaises(ValueError):verify(p)
    def test_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            p=self.copy_bundle(temp);(p/'link').symlink_to(p/'assets/character.md')
            with self.assertRaises(ValueError):verify(p)
    def test_unsafe_path_rejected(self):
        for name in ['../x','/tmp/x','tools/../character.md','tools\\x','C:/x']:
            with self.subTest(name=name):
                with self.assertRaises(ValueError):safe_path(ROOT,name)
    def test_cli_first_page_marked(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):code=main(['--stage','00-start','--part','1'])
        self.assertEqual(code,0);self.assertIn('--- END PART 1/',out.getvalue());self.assertIn('NEXT:',out.getvalue())
    def test_cli_bad_part_fails(self):
        with contextlib.redirect_stderr(io.StringIO()):code=main(['--stage','00-start','--part','999'])
        self.assertEqual(code,2)
    def test_rubric_main_quality_and_diagnostics_preserved(self):
        spec=(ROOT/'references/authoring-rubric.md').read_text()
        data=json.loads((ROOT/'references/provenance.json').read_text())
        import hashlib
        section=spec.split('## Main Quality Tests',1)[1]
        self.assertEqual(hashlib.sha256(section.encode()).hexdigest(), data['preserved_main_quality_sha256'])

if __name__=='__main__':unittest.main()
