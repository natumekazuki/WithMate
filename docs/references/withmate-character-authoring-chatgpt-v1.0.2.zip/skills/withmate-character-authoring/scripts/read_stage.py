#!/usr/bin/env python3
"""Read exact stage-source ranges from an installed authoring skill; verify its files and print exact stage-source ranges.

Python 3.10+, stdlib only. No network, writes, model calls or approval decisions.
A displayed range / matching hash is not proof of comprehension or compliance.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
LIMIT = 8 * 1024 * 1024


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(root: Path, name: str) -> Path:
    p = PurePosixPath(name)
    if (not name or p.is_absolute() or '..' in p.parts or '\\' in name
            or str(p) != name or ':' in name):
        raise ValueError(f'unsafe manifest path: {name!r}')
    dest = root.joinpath(*p.parts)
    for node in [dest, *list(dest.parents)[:len(p.parts)-1]]:
        if node.is_symlink():
            raise ValueError(f'symlink is not allowed: {name}')
    if not dest.is_file():
        raise ValueError(f'missing regular file: {name}')
    if root.resolve() not in dest.resolve().parents:
        raise ValueError(f'outside bundle: {name}')
    return dest


def verify(root: Path) -> dict[str, Any]:
    mp = safe_path(root, 'manifest.json')
    if mp.stat().st_size > LIMIT:
        raise ValueError('manifest too large')
    m = json.loads(mp.read_text(encoding='utf-8'))
    files = m['files']
    if not isinstance(files, dict) or not files or len(files) > 100:
        raise ValueError('invalid manifest file map')
    expected = set(files) | {'manifest.json'}
    entries = list(root.rglob('*'))
    if any(p.is_symlink() for p in entries):
        raise ValueError('symlink in bundle')
    actual = {p.relative_to(root).as_posix() for p in entries if p.is_file()}
    if actual != expected:
        raise ValueError(f'file-set mismatch: missing={sorted(expected-actual)}, extra={sorted(actual-expected)}')
    expected_dirs = {str(parent) for n in files for parent in PurePosixPath(n).parents if str(parent) != '.'}
    actual_dirs = {p.relative_to(root).as_posix() for p in entries if p.is_dir()}
    if actual_dirs != expected_dirs:
        raise ValueError('unexpected or missing directories')
    total = 0
    for name, record in files.items():
        p = safe_path(root, name)
        size = p.stat().st_size
        total += size
        if total > LIMIT or size != record['bytes']:
            raise ValueError(f'size mismatch / resource limit: {name}')
        if sha(p.read_bytes()) != record['sha256']:
            raise ValueError(f'hash mismatch: {name}')
    plan = json.loads((root/'references/read-plan.json').read_text(encoding='utf-8'))
    if plan['revision'] != m['revision']:
        raise ValueError('plan/manifest revision mismatch')
    return m


def spans(text: str) -> list[tuple[int, str, int, int]]:
    """Return headings and original line offsets; fenced headings are ignored."""
    lines = text.splitlines(keepends=True)
    headings = []
    fence = ''
    fence_len = 0
    comment = False
    for i, raw in enumerate(lines):
        line = raw.rstrip('\r\n')
        if comment:
            if '-->' in line:
                comment = False
            continue
        if '<!--' in line:
            if '-->' not in line.split('<!--',1)[1]:
                comment = True
            continue
        if fence:
            if re.fullmatch(r' {0,3}' + re.escape(fence) + '{' + str(fence_len) + r',}\s*', line):
                fence = ''
            continue
        f = re.match(r'^ {0,3}(`{3,}|~{3,})', line)
        if f:
            fence, fence_len = f[1][0], len(f[1])
            continue
        h = re.match(r'^(#{1,6})\s+(.+?)\s*$', line)
        if h:
            headings.append((len(h[1]), line, i))
    return [(lev, heading, start,
             next((s for lv, _, s in headings[n+1:] if lv <= lev), len(lines)))
            for n, (lev, heading, start) in enumerate(headings)]


def source_range(root: Path, entry: dict[str, Any]) -> tuple[list[str], int, int]:
    text = safe_path(root, entry['path']).read_text(encoding='utf-8')
    lines = text.splitlines(keepends=True)
    if 'heading' not in entry:
        return lines, 0, len(lines)
    found = [s for s in spans(text) if s[1] == entry['heading']]
    if len(found) != 1:
        raise ValueError(f"heading must match once: {entry['path']} {entry['heading']} ({len(found)})")
    _, _, start, end = found[0]
    return lines, start, end


def chunks(root: Path, stage: dict[str, Any], kind: str,
           max_chars: int = 4800) -> list[tuple[str, int, int, str]]:
    out = []
    for entry in stage['reads']:
        if entry.get('kind',kind) != kind:
            continue
        lines, start, end = source_range(root, entry)
        cursor, buf, chars = start, [], 0
        for i in range(start,end):
            line = lines[i]
            if len(line) > max_chars:
                raise ValueError(f'line too long for bounded display: {entry["path"]}:{i+1}')
            if buf and chars+len(line) > max_chars:
                out.append((entry['path'],cursor+1,i,''.join(buf)))
                cursor, buf, chars = i, [], 0
            buf.append(line); chars += len(line)
        if buf:
            out.append((entry['path'],cursor+1,end,''.join(buf)))
    return out


def paginate(items: list[tuple[str,int,int,str]], max_chars: int) -> list[list[tuple[str,int,int,str]]]:
    """Group small adjacent source ranges without altering their text."""
    pages: list[list[tuple[str,int,int,str]]] = []
    current: list[tuple[str,int,int,str]] = []
    used = 0
    for item in items:
        cost = len(item[3]) + len(item[0]) + 180
        if current and used + cost > max_chars:
            pages.append(current)
            current, used = [], 0
        current.append(item)
        used += cost
    if current:
        pages.append(current)
    return pages


def stage_by_id(plan: dict[str, Any], key: str) -> dict[str, Any]:
    hits = [s for s in plan['stages'] if s['id'] == key]
    if len(hits) != 1:
        raise ValueError(f'unknown or repeated stage: {key}')
    return hits[0]


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=ROOT)
    p.add_argument('--verify', action='store_true')
    p.add_argument('--list', action='store_true')
    p.add_argument('--check-plan', action='store_true')
    p.add_argument('--stage')
    p.add_argument('--kind', choices=['new','revise'], default='new')
    p.add_argument('--part', type=int, default=1)
    p.add_argument('--max-chars',type=int,default=4800)
    args=p.parse_args(argv)
    try:
        root=args.root.resolve()
        manifest=verify(root)
        plan=json.loads((root/'references/read-plan.json').read_text(encoding='utf-8'))
        if not 500 <= args.max_chars <= 6000:
            raise ValueError('--max-chars must be 500..6000')
        if args.verify:
            print(json.dumps({'bundle_integrity':'pass','revision':manifest['revision'],
                              'verified_files':len(manifest['files']),
                              'comprehension_verified':False,'release_authorized':False},ensure_ascii=False,indent=2))
        if args.list or args.check_plan:
            rows=[]
            for stage in plan['stages']:
                for kind in (['new','revise'] if args.check_plan else [args.kind]):
                    parts=chunks(root,stage,kind,args.max_chars-300)
                    rows.append({'stage':stage['id'],'label':stage['label'],'kind':kind,'parts':len(paginate(parts,args.max_chars)),
                                 'source_chars':sum(len(x[3]) for x in parts)})
            print(json.dumps(rows,ensure_ascii=False,indent=2))
        if args.stage:
            stage=stage_by_id(plan,args.stage)
            parts=paginate(chunks(root,stage,args.kind,args.max_chars-300),args.max_chars)
            if not 1 <= args.part <= len(parts):
                raise ValueError(f'part must be 1..{len(parts)}')
            page=parts[args.part-1]
            header={'revision':manifest['revision'],'stage':stage['id'],'kind':args.kind,
                    'part':args.part,'total_parts':len(parts),'goal':stage['goal'],'stop':stage['stop']}
            print(json.dumps(header,ensure_ascii=False))
            for path,start,end,text in page:
                identity={'path':path,'source_lines':f'{start}-{end}',
                          'source_file_sha256':manifest['files'][path]['sha256'],
                          'display_payload_sha256':sha(text.encode('utf-8'))}
                print(json.dumps(identity,ensure_ascii=False))
                print('--- BEGIN SOURCE (unabridged range) ---')
                sys.stdout.write(text)
                if not text.endswith('\n'): print()
                print('--- END SOURCE ---')
            print(f'--- END PART {args.part}/{len(parts)} ---')
            if args.part<len(parts):print(f'NEXT: --stage {args.stage} --kind {args.kind} --part {args.part+1}')
        if not any([args.verify,args.list,args.check_plan,args.stage]):
            p.error('choose --verify, --list, --check-plan or --stage')
    except (OSError,ValueError,KeyError,TypeError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 2
    return 0


if __name__=='__main__':
    raise SystemExit(main())
