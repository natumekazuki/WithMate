"""Skill packaging and routing-data checks, not an LLM or user-dialogue eval."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import re
import unittest
from read_stage import ROOT, verify, source_range

class SkillPackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.skill=(ROOT/'SKILL.md').read_text()
        cls.plan=json.loads((ROOT/'references/read-plan.json').read_text())
        cls.provenance=json.loads((ROOT/'references/provenance.json').read_text())

    def test_single_skill_entry(self):
        self.assertEqual([p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name.lower()=='skill.md'],['SKILL.md'])

    def test_frontmatter_identity(self):
        self.assertTrue(self.skill.startswith('---\nname: withmate-character-authoring\ndescription: >-\n'))
        self.assertEqual(ROOT.name,'withmate-character-authoring')
        self.assertIn('WithMate V5',self.skill.split('\n---\n',1)[0])

    def test_entry_is_bounded(self):
        self.assertLessEqual(len(self.skill.splitlines()),150)
        self.assertLessEqual(len(self.skill),6000)

    def test_all_markdown_links_resolve_inside_skill(self):
        for path in ROOT.rglob('*.md'):
            for link in re.findall(r'\]\(([^\s)]+)\)',path.read_text()):
                if '://' in link or link.startswith('#'):continue
                target=(path.parent/link.split('#',1)[0]).resolve()
                with self.subTest(path=str(path),link=link):
                    self.assertTrue(target.is_file())
                    self.assertIn(ROOT.resolve(),target.parents)

    def test_four_guides_linked_from_entry(self):
        for name in ['research.md','drafting.md','validation.md','deployment.md']:
            self.assertIn('](references/'+name+')',self.skill)

    def test_guides_include_every_ordered_source_range(self):
        lookup={'alignment':'research.md','calibration':'drafting.md','validation':'validation.md','delivery':'deployment.md'}
        stages={s['id']:s for s in self.plan['stages']}
        for profile, filename in lookup.items():
            guide=(ROOT/'references'/filename).read_text()
            for sid in self.plan['reply_profiles'][profile]['stages']:
                self.assertIn('### '+sid,guide)
                for entry in stages[sid]['reads']:
                    self.assertIn('['+entry['path']+']',guide)
                    self.assertIn('`'+entry.get('heading','全文')+'`',guide)

    def test_runtime_template_preserved_except_description_placeholder(self):
        text=(ROOT/'assets/character.md').read_text(encoding='utf-8')
        current='{character_self_introduction_in_own_voice}'
        self.assertEqual(text.count(current),1)
        baseline=text.replace(current,'{character_profile_bio}',1)
        self.assertEqual(hashlib.sha256(baseline.encode('utf-8')).hexdigest(),self.provenance['preserved_runtime_template_sha256'])
        self.assertEqual(hashlib.sha256(text.encode('utf-8')).hexdigest(),self.provenance['current_runtime_template_sha256'])

    def test_stage_plan_contains_no_source_zip_bootstrap(self):
        entries=[x['path'] for s in self.plan['stages'] for x in s['reads']]
        self.assertNotIn('00-START-HERE.md',entries)
        self.assertEqual(entries[0],'references/workflow.md')
        self.assertIn('登録済みSkillの参照機構',self.skill)

    def test_preserved_main_quality_tests(self):
        text=(ROOT/'references/authoring-rubric.md').read_text().split('## Main Quality Tests',1)[1]
        self.assertEqual(hashlib.sha256(text.encode()).hexdigest(),self.provenance['preserved_main_quality_sha256'])

    def test_no_generated_case_files_or_dependencies(self):
        self.assertFalse((ROOT/'character.md').exists())
        self.assertFalse((ROOT/'character-notes.md').exists())
        for p in ROOT.rglob('*'):
            self.assertFalse(p.is_symlink())
            self.assertNotIn(p.name,{'node_modules','.env','__pycache__','.git'})

    def test_scripts_compile(self):
        for p in (ROOT/'scripts').glob('*.py'):
            compile(p.read_text(),str(p),'exec')

    def test_runtime_utilities_have_no_network_imports(self):
        prohibited={'requests','httpx','socket','subprocess','openai'}
        for name in ['read_stage.py','validate_pack.py']:
            tree=ast.parse((ROOT/'scripts'/name).read_text())
            imports=set()
            for node in ast.walk(tree):
                if isinstance(node,ast.Import):imports.update(i.name.split('.')[0] for i in node.names)
                elif isinstance(node,ast.ImportFrom):imports.add((node.module or '').split('.')[0])
            self.assertFalse(imports & prohibited)

    def test_declares_controller_limit(self):
        self.assertIn('外部コントローラ',self.skill)
        self.assertFalse(self.provenance['external_turn_controller_included'])
        self.assertFalse(self.provenance['model_behavior_verified'])

    def test_entry_retains_affirmative_and_closed_definition(self):
        for term in ['原則肯定形','名称・暗示・禁止文ごと省く','不要な予防文は行全体を削除','8,000文字以内']:
            self.assertIn(term,self.skill)

    def test_entry_asks_for_real_feedback_at_final_response(self):
        for term in ['初回の完成対象は照合案','次の実ユーザー入力','最終応答で返す','provisionalは品質・承認状態']:
            self.assertIn(term,self.skill)

    def test_claim_types_not_conflated(self):
        for term in ['構造検査','意味監査','実出力の品質','実作業の成功','採用承認']:
            self.assertIn(term,self.skill)

    def test_parent_is_precreated(self):
        self.assertIn('事前作成済み親ページURL1件',self.skill)
        self.assertIn('親の名前探索・新規作成・template設定は作業対象外',self.skill)

    def test_no_oneshot_delegation(self):
        self.assertIn('「続けて」「おまかせ」',self.skill)
        self.assertIn('明示的な確認省略・一度での作成だけ',self.skill)

if __name__=='__main__':
    unittest.main()
