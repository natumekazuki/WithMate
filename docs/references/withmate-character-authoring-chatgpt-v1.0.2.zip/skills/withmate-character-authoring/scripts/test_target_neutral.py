"""Source wiring and format regression only, not character or model-quality tests."""
import json
import unittest
from read_stage import ROOT, source_range
from validate_pack import Validator
from test_validate_pack import CONTRACT, fixture


def part(path, heading):
    lines, start, end = source_range(ROOT, {'path': path, 'heading': heading})
    return ''.join(lines[start:end])


class TargetNeutralTests(unittest.TestCase):
    def test_same_runtime_contract(self):
        self.assertEqual(CONTRACT['pack_files'], ['character.md', 'character-notes.md'])
        self.assertEqual(CONTRACT['schema'], 'withmate-character-v5')
        self.assertEqual(CONTRACT['runtime_max_chars'], 8000)
        self.assertEqual(CONTRACT['runtime_h2'], [
            'Baseline Presence', 'Identity Core', 'Attention and Appraisal',
            'Social Intent / User Relationship', 'Emotional Dynamics and Core Tensions',
            'Thinking and Action Style', 'Voice Rules', 'State Modulation',
            'Character Priority', 'Minimal Reliability'])
        self.assertEqual(CONTRACT['voice_fields']['Identity Invariants'], [
            '一人称', 'ユーザーの呼び方', 'ユーザーからの呼ばれ方', '敬語度・表記'])

    def test_notes_target_labels_do_not_change_structure(self):
        # These are artificial labels on the SAME fixture. No simulated character
        # performance is generated or evaluated here.
        for label in ['アニメ', 'ゲーム', 'VTuber', 'オリジナル', '非言語マスコット']:
            with self.subTest(label=label):
                data = fixture()
                notes = data['character-notes.md'].decode().replace(
                    '## Target\n', '## Target\n\n- 対象の定義範囲: 構造試験用・' + label + '\n', 1)
                data['character-notes.md'] = notes.encode()
                result = Validator(CONTRACT).validate(data)
                self.assertTrue(result['structural_pass'], result['errors'])
                self.assertFalse(result['release_authorized'])

    def test_read_plan_has_only_new_revise_branching(self):
        plan = json.loads((ROOT / 'references/read-plan.json').read_text())
        for stage in plan['stages']:
            for entry in stage['reads']:
                self.assertLessEqual(set(entry), {'path', 'heading', 'kind'})
                if 'kind' in entry:
                    self.assertIn(entry['kind'], {'new', 'revise'})
        self.assertEqual(set(plan['reply_profiles']), {'alignment', 'calibration', 'validation', 'delivery'})

    def test_source_policy_wiring(self):
        stages = {s['id']: s for s in json.loads((ROOT / 'references/read-plan.json').read_text())['stages']}
        self.assertIn({'path': 'references/source-and-rights-policy.md', 'heading': '## Target Definition Scope'}, stages['00-start']['reads'])
        self.assertIn({'path': 'references/source-and-rights-policy.md'}, stages['10-research']['reads'])
        for stage in ['30-calibration', '40-validation']:
            self.assertIn({'path': 'references/source-and-rights-policy.md', 'heading': '## Evidence to Interpretation'}, stages[stage]['reads'])

    def test_profile_source_fallback_is_documented(self):
        text = part('references/source-and-rights-policy.md', '## Frontmatter Description Sources')
        for value in ['創作者の設定資料', '要約', '必須条件にしない', '外部で公開済み']:
            self.assertIn(value, text)

    def test_creator_definition_is_in_source_and_notes(self):
        for path in ['references/source-and-rights-policy.md', 'assets/character-notes.md']:
            self.assertIn('creator-definition', (ROOT / path).read_text())
        self.assertIn('user-providedは入手経路', (ROOT / 'assets/character-notes.md').read_text())

    def test_adaptation_does_not_replace_output_feedback_in_docs(self):
        text = part('references/source-and-rights-policy.md', '## Evidence to Interpretation')
        self.assertIn('無言の対象', text)
        self.assertIn('D1', text)
        self.assertIn('D2', text)
        self.assertIn('一次sourceには数えない', text)

    def test_closure_still_uses_adopted_information(self):
        text = (ROOT / 'references/runtime-self-containment.md').read_text()
        self.assertIn('原則として肯定形', text)
        self.assertIn('不要な固有情報は名称・暗示・禁止文ごと省く', text)
        self.assertIn('frontmatterを含むcharacter.md内', text)
        self.assertNotIn('ルート・End・調査時点', text)

    def test_scope_management_stays_outside_runtime_template(self):
        text = (ROOT / 'assets/character.md').read_text()
        for term in ['creator-definition', 'Source class', '対象の定義範囲', '対象の版・時点', 'アニメ', 'VTuber', 'End']:
            self.assertNotIn(term, text)


if __name__ == '__main__':
    unittest.main()
