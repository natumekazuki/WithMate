"""Static signature-greeting instruction checks, not character-generation tests."""
from pathlib import Path
import hashlib
import json
import unittest

ROOT = Path(__file__).resolve().parents[1]


class SignatureGreetingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.entry = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        text = (ROOT / 'references/withmate-v5-character-format.md').read_text(encoding='utf-8')
        cls.description = text.split('## Frontmatter Description\n', 1)[1].split('\n## ', 1)[0]

    def test_present_greeting_is_included(self):
        for text in [self.entry, self.description]:
            self.assertIn('本人に特徴的な挨拶・名乗り', text)
            self.assertIn('descriptionの冒頭などへ自然に取り入れる', text)
        self.assertIn('特徴的な挨拶がある場合に取り入れているか', self.description)

    def test_not_limited_to_vtubers_or_invented_for_every_character(self):
        for term in ['VTuberに限定せず全対象', '特徴的な挨拶がない場合は無理に作らず',
                     '全員共通の挨拶を要求しないこと']:
            self.assertIn(term, self.description)

    def test_source_context_and_exact_short_phrase_are_preserved(self):
        for term in ['語句・表記・リズム', '本人の使用・正確な表記・使用文脈',
                     '開始・終了・時間帯限定', '視聴者側の返し',
                     'Frontmatter Description Notes', '短い挨拶の引用部分',
                     '長いコール＆レスポンスや台詞の全文は転載しない']:
            self.assertIn(term, self.description)

    def test_conciseness_and_existing_runtime_boundary_remain(self):
        for term in ['1〜3文・160文字以内', '重複を整理', '人となりも伝える',
                     '毎ターンの挨拶や固定返答として繰り返す規則にも変えない',
                     'revision/hash', '構造検査とは別の意味・文体レビュー',
                     '本人が自分を紹介しているか']:
            self.assertIn(term, self.description)

    def test_changed_files_match_manifest_and_version(self):
        manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
        for name in ['SKILL.md', 'references/withmate-v5-character-format.md',
                     'references/provenance.json', 'scripts/test_signature_greeting.py']:
            with self.subTest(name=name):
                data = (ROOT / name).read_bytes()
                self.assertEqual(manifest['files'][name]['bytes'], len(data))
                self.assertEqual(manifest['files'][name]['sha256'], hashlib.sha256(data).hexdigest())
        provenance = json.loads((ROOT / 'references/provenance.json').read_text(encoding='utf-8'))
        self.assertEqual(manifest['version'], provenance['skill_version'])
        self.assertFalse(provenance['model_behavior_verified'])


if __name__ == '__main__':
    unittest.main()
