"""r2 structure/record tests only. No semantic, user-dialogue or model evaluation."""
from hashlib import sha256
import json
from pathlib import Path
import unittest
from validate_pack import Validator
from test_validate_pack import CONTRACT, fixture
from read_stage import ROOT, source_range

class ClosureRecordTests(unittest.TestCase):
    def patch(self, old, new):
        data=fixture()
        data['character-notes.md']=data['character-notes.md'].decode().replace(old,new).encode()
        return data
    def codes(self,data):
        return {x['code'] for x in Validator(CONTRACT).validate(data)['errors']}
    def test_good_record_does_not_authorize_release(self):
        result=Validator(CONTRACT).validate(fixture())
        self.assertTrue(result['structural_pass'])
        self.assertFalse(result['release_authorized'])
    def test_missing_closure_heading(self):
        self.assertIn('E_SECTION',self.codes(self.patch('### Runtime Closure Review','### Other')))
    def test_duplicate_closure_heading(self):
        self.assertIn('E_SECTION',self.codes(self.patch('### Runtime Closure Review','### Runtime Closure Review\nx\n### Runtime Closure Review')))
    def test_closure_under_wrong_parent(self):
        self.assertIn('E_SECTION',self.codes(self.patch('### Runtime Closure Review','## Other\n### Runtime Closure Review')))
    def test_missing_evidence(self):
        data=fixture()
        text=data['character-notes.md'].decode()
        text='\n'.join(l for l in text.splitlines() if not l.startswith('- Review evidence:'))
        data['character-notes.md']=text.encode()
        self.assertIn('E_CLOSURE_EVIDENCE',self.codes(data))
    def test_empty_evidence(self):
        self.assertIn('E_CLOSURE_EVIDENCE',self.codes(self.patch('Review evidence: fixtureの構造だけを試す模擬記録。実際の意味監査passの証拠ではない。','Review evidence: ')))
    def test_unknown_evidence(self):
        self.assertIn('E_CLOSURE_EVIDENCE',self.codes(self.patch('Review evidence: fixtureの構造だけを試す模擬記録。実際の意味監査passの証拠ではない。','Review evidence: unknown')))
    def test_hash_stale(self):
        digest=sha256(fixture()['character.md']).hexdigest()
        self.assertIn('E_CLOSURE_HASH',self.codes(self.patch('対象runtime SHA-256: '+digest,'対象runtime SHA-256: '+'0'*64)))
    def test_failed_review_blocks_pack(self):
        self.assertIn('E_CLOSURE_REVIEW',self.codes(self.patch('Review status: pass','Review status: fail')))
    def test_not_run_blocks_pack(self):
        self.assertIn('E_CLOSURE_REVIEW',self.codes(self.patch('Review status: pass','Review status: not-run')))
    def test_inconclusive_blocks_pack(self):
        self.assertIn('E_CLOSURE_REVIEW',self.codes(self.patch('Review status: pass','Review status: inconclusive')))
    def test_unknown_enum(self):
        self.assertIn('E_ENUM',self.codes(self.patch('Review status: pass','Review status: approved')))
    def test_fenced_record_not_structural(self):
        self.assertIn('E_SECTION',self.codes(self.patch('### Runtime Closure Review','```md\n### Runtime Closure Review')))
    def test_semantic_false_positive_is_explicit_limit(self):
        # A self-reported pass remains insufficient: this intentionally vague fixture
        # is not made semantically valid by its receipt.
        result=Validator(CONTRACT).validate(fixture())
        self.assertIn('runtime自己完結性',result['manual_checks_required'][0])
        self.assertIn('認証しません',result['notice'])
        self.assertFalse(result['release_authorized'])

class WiringTests(unittest.TestCase):
    def test_policy_in_research_calibration_validation(self):
        plan=json.loads((ROOT/'references/read-plan.json').read_text())
        for s in plan['stages']:
            if s['id'] in {'10-research','30-calibration','40-validation'}:
                self.assertIn({'path':'references/runtime-self-containment.md'},s['reads'])
    def test_turn_boundaries_in_gate_phases(self):
        plan=json.loads((ROOT/'references/read-plan.json').read_text())
        for s in plan['stages']:
            if s['id'] in {'00-start','20-alignment','30-calibration','50-approval','60-delivery'}:
                self.assertIn({'path':'references/output-contract.md','heading':'## Dialogue Turn Boundaries'},s['reads'])
    def test_notes_template_has_closure_fields(self):
        lines,a,b=source_range(ROOT,{'path':'assets/character-notes.md','heading':'### Runtime Closure Review'})
        body=''.join(lines[a:b])
        for name in CONTRACT['closure_review']['fields']:
            self.assertIn('- '+name+':',body)
    def test_runtime_template_no_case_specific_names(self):
        text=(ROOT/'assets/character.md').read_text()
        for token in ['エリス','マリーゴールド','日下部彰','狂乱','絆の形End']:
            self.assertNotIn(token,text)
    def test_runtime_template_has_no_review_record(self):
        self.assertNotIn('### Runtime Closure Review',(ROOT/'assets/character.md').read_text())
    def test_bootstrap_must_distinguish_target_from_dialogue(self):
        text=(ROOT/'references/output-contract.md').read_text()
        self.assertIn('対象指定と工程の通過は別',text)
        self.assertIn('provisionalは品質・承認の状態であり、対話を省略する権限ではない',text)

if __name__=='__main__':unittest.main()
