"""Synthetic structural tests only; fixtures are NOT character-quality evidence."""
from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
import tempfile
import unittest
import warnings
from zipfile import ZipFile
from validate_pack import Validator, load_pack

CONTRACT = json.loads(Path(__file__).with_name('validation-contract.json').read_text())


def fixture() -> dict[str, bytes]:
    chunks = ['---\nschema: withmate-character-v5\nname: "構造検査用"\ndescription: "検査用の架空プロフィール。"\n---\n\n# Character Kernel\n']
    for heading in CONTRACT['runtime_h2']:
        chunks.append(f'\n## {heading}\n\n構造検査用の文章。品質を評価するための内容ではない。\n')
        if heading == 'Voice Rules':
            for subheading, labels in CONTRACT['voice_fields'].items():
                chunks.append(f'\n### {subheading}\n')
                for label in labels:
                    value = '["検査用", "検査"]' if label == 'ユーザーからの呼ばれ方' else '構造検査用の規則。'
                    chunks.append(f'\n- {label}: {value}\n')
    runtime = ''.join(chunks)
    digest = sha256(runtime.encode()).hexdigest()
    special = {
        'Target': '- Notion parent URL: https://www.notion.so/0123456789abcdef0123456789abcdef\n',
        'Workflow State': f'- Mode: collaborative\n- Stage: provisional\n- Candidate revision: r01\n- Candidate runtime SHA-256（LF正規化後のファイル全体）: {digest}\n- Approval status: not-requested\n',
        'Calibration Brief': '- 利用範囲: conversation-only\n- 非該当理由: 自動検査用のfixture。実ユーザーの指定を表すものではない。\n',
        'Character Address Evidence': '- runtime採用配列（character.mdと同じ表記・並び）: ["検査用", "検査"]\n- 配列の確認状態: pending\n',
        'Visual Identity / Color Notes': '| Role | HEX | 区分 | Source | 方法 | 理由 | 確度 |\n| --- | --- | --- | --- | --- | --- | --- |\n| メインカラー | #112233 | authoring-derived | fixture | 検査用 | 検査用 | 実Character未評価 |\n| サブカラー | #AABBCC | authoring-derived | fixture | 検査用 | 検査用 | 実Character未評価 |\n',
        'Approval Record': '- Approval status: not-requested\n',
        'Runtime Handoff': f'### Runtime Closure Review\n\n- 対象runtime SHA-256: {digest}\n- Review status: pass\n- Review evidence: fixtureの構造だけを試す模擬記録。実際の意味監査passの証拠ではない。\n',
    }
    notes = '# Character Notes\n'
    for heading in CONTRACT['notes_h2']:
        notes += f'\n## {heading}\n\n' + special.get(heading, '構造検査用の記録。実ユーザー確認や品質検証の証拠ではない。\n')
    return {'character.md': runtime.encode(), 'character-notes.md': notes.encode()}


def alter_runtime(files: dict[str, bytes], old: str, new: str, rehash: bool = True) -> dict[str, bytes]:
    result = files.copy()
    old_hash = sha256(files['character.md']).hexdigest()
    result['character.md'] = files['character.md'].decode().replace(old, new).encode()
    if rehash:
        result['character-notes.md'] = files['character-notes.md'].replace(old_hash.encode(), sha256(result['character.md']).hexdigest().encode())
    return result


class PackTests(unittest.TestCase):
    def codes(self, data: dict[str, bytes]) -> set[str]:
        return {e['code'] for e in Validator(CONTRACT).validate(data)['errors']}

    def test_valid_structure_is_not_release_authorization(self):
        r = Validator(CONTRACT).validate(fixture())
        self.assertTrue(r['structural_pass'], r)
        self.assertFalse(r['release_authorized'])

    def test_missing_file(self):
        self.assertIn('E_PACK_FILES', self.codes({'character.md': b''}))

    def test_empty_aliases(self):
        self.assertIn('E_ARRAY_TYPE', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '[]')))

    def test_alias_object(self):
        self.assertIn('E_ARRAY_ITEMS', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '[{"name":"検査用"}]')))

    def test_alias_duplicates(self):
        self.assertIn('E_ARRAY_DUPLICATE', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '["検査用", "検査用"]')))

    def test_alias_blank(self):
        self.assertIn('E_ARRAY_ITEMS', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '[" "]')))

    def test_alias_non_string(self):
        self.assertIn('E_ARRAY_ITEMS', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '[1]')))

    def test_alias_broken_json(self):
        self.assertIn('E_ARRAY_JSON', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '["検査用",]')))

    def test_alias_notes_mismatch(self):
        self.assertIn('E_ARRAY_MISMATCH', self.codes(alter_runtime(fixture(), '["検査用", "検査"]', '["別名"]')))

    def test_duplicate_frontmatter(self):
        self.assertIn('E_FRONTMATTER_DUPLICATE', self.codes(alter_runtime(fixture(), 'schema: withmate-character-v5', 'schema: withmate-character-v5\nschema: withmate-character-v5')))

    def test_unquoted_name(self):
        self.assertIn('E_FRONTMATTER_VALUE', self.codes(alter_runtime(fixture(), 'name: "構造検査用"', 'name: 構造検査用')))

    def test_extra_frontmatter_key(self):
        self.assertIn('E_FRONTMATTER_KEYS', self.codes(alter_runtime(fixture(), 'name: "構造検査用"', 'name: "構造検査用"\nfoo: "extra"')))

    def test_placeholder(self):
        self.assertIn('E_PLACEHOLDER', self.codes(alter_runtime(fixture(), 'name: "構造検査用"', 'name: "{character_name}"')))

    def test_size_limit(self):
        self.assertIn('E_RUNTIME_LENGTH', self.codes(alter_runtime(fixture(), '# Character Kernel', '# Character Kernel\n' + 'あ' * 8001)))

    def test_hash_stale(self):
        self.assertIn('E_HASH', self.codes(alter_runtime(fixture(), '構造検査用の文章', '変更後の文章', rehash=False)))

    def test_bad_utf8(self):
        f = fixture(); f['character.md'] = b'\xff'
        self.assertIn('E_UTF8', self.codes(f))

    def test_crlf(self):
        f = fixture(); f['character.md'] = f['character.md'].replace(b'\n', b'\r\n')
        self.assertIn('E_LF', self.codes(f))

    def test_heading_only_in_fence(self):
        f = alter_runtime(fixture(), '## Identity Core', '```md\n## Identity Core\n```')
        self.assertIn('E_SECTION', self.codes(f))

    def test_heading_only_in_comment(self):
        f = alter_runtime(fixture(), '## Identity Core', '<!-- ## Identity Core -->')
        self.assertIn('E_SECTION', self.codes(f))

    def test_empty_field_does_not_consume_next_line(self):
        self.assertIn('E_EMPTY_FIELD', self.codes(alter_runtime(fixture(), '- 一人称: 構造検査用の規則。', '- 一人称: ')))

    def test_wrong_mode(self):
        f = fixture(); f['character-notes.md'] = f['character-notes.md'].replace(b'Mode: collaborative', b'Mode: whatever')
        self.assertIn('E_ENUM', self.codes(f))

    def test_one_shot_does_not_become_approved(self):
        f = fixture(); n = f['character-notes.md'].decode().replace('Mode: collaborative', 'Mode: one-shot').replace('Stage: provisional', 'Stage: approved').replace('Approval status: not-requested', 'Approval status: approved')
        f['character-notes.md'] = n.encode()
        self.assertIn('E_ONESHOT', self.codes(f))

    def test_work_scope_requires_work_sections(self):
        f = fixture(); f['character-notes.md'] = f['character-notes.md'].replace(b'conversation-only', b'conversation-and-work')
        self.assertIn('E_SECTION', self.codes(f))

    def test_lowercase_color(self):
        f = fixture(); f['character-notes.md'] = f['character-notes.md'].replace(b'#AABBCC', b'#aabbcc')
        self.assertIn('E_COLOR_HEX', self.codes(f))

    def test_approved_pending_addresses(self):
        f = fixture(); f['character-notes.md'] = f['character-notes.md'].replace(b'Stage: provisional', b'Stage: approved').replace(b'Approval status: not-requested', b'Approval status: approved')
        self.assertIn('E_ADDRESS_APPROVAL', self.codes(f))

    def test_soft_description_limit_is_warning(self):
        f = alter_runtime(fixture(), 'description: "検査用の架空プロフィール。"', 'description: "' + 'あ' * 161 + '"')
        r = Validator(CONTRACT).validate(f)
        self.assertTrue(r['structural_pass'], r)
        self.assertIn('W_DESCRIPTION_LENGTH', {w['code'] for w in r['warnings']})

    def test_valid_zip(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'pack.zip'
            with ZipFile(p, 'w') as z:
                for n, b in fixture().items(): z.writestr(n, b)
            self.assertEqual(fixture(), load_pack(p, CONTRACT['pack_files']))

    def test_zip_extra_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'pack.zip'
            with ZipFile(p, 'w') as z:
                for n, b in fixture().items(): z.writestr(n, b)
                z.writestr('README.md', 'extra')
            with self.assertRaises(ValueError): load_pack(p, CONTRACT['pack_files'])

    def test_zip_nested(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'pack.zip'
            with ZipFile(p, 'w') as z:
                for n, b in fixture().items(): z.writestr('folder/'+n, b)
            with self.assertRaises(ValueError): load_pack(p, CONTRACT['pack_files'])

    def test_zip_duplicate(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'pack.zip'
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                with ZipFile(p, 'w') as z:
                    for n, b in fixture().items(): z.writestr(n, b)
                    z.writestr('character.md', 'duplicate')
            with self.assertRaises(ValueError): load_pack(p, CONTRACT['pack_files'])


def add_runtime_heading_case(heading: str, index: int) -> None:
    def test(self: PackTests):
        f = alter_runtime(fixture(), f'## {heading}\n', f'## Changed {heading}\n')
        self.assertIn('E_SECTION', self.codes(f))
    setattr(PackTests, f'test_required_runtime_heading_{index:02}', test)


def add_notes_heading_case(heading: str, index: int) -> None:
    def test(self: PackTests):
        f = fixture(); f['character-notes.md'] = f['character-notes.md'].replace(f'## {heading}\n'.encode(), f'## Changed {heading}\n'.encode())
        self.assertIn('E_SECTION', self.codes(f))
    setattr(PackTests, f'test_required_notes_heading_{index:02}', test)


def add_voice_field_case(label: str, index: int) -> None:
    def test(self: PackTests):
        f = alter_runtime(fixture(), f'- {label}:', f'- Changed {label}:')
        self.assertIn('E_FIELD', self.codes(f))
    setattr(PackTests, f'test_required_voice_field_{index:02}', test)


for i, h in enumerate(CONTRACT['runtime_h2']): add_runtime_heading_case(h, i)
for i, h in enumerate(CONTRACT['notes_h2']): add_notes_heading_case(h, i)
for i, f in enumerate(x for labels in CONTRACT['voice_fields'].values() for x in labels): add_voice_field_case(f, i)

if __name__ == '__main__': unittest.main(verbosity=2)
