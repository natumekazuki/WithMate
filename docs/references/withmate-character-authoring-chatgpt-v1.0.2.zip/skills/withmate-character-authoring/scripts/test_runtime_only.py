"""Candidate structure checks; these tests make no claim about model behavior."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from test_validate_pack import CONTRACT, fixture
from validate_pack import Validator, main

class RuntimeOnlyTests(unittest.TestCase):
    def runtime(self): return fixture()["character.md"]
    def check(self, data): return Validator(CONTRACT).validate_runtime(data)
    def codes(self, data): return {e["code"] for e in self.check(data)["errors"]}
    def test_candidate_needs_no_notes_or_colors(self):
        r=self.check(self.runtime())
        self.assertTrue(r["structural_pass"])
        self.assertFalse(r["release_authorized"])
        self.assertEqual(r["scope"],"implemented-runtime-structure-only")
        self.assertNotIn("notes_bytes",r["metrics"])
    def test_missing_frontmatter(self):
        self.assertIn("E_FRONTMATTER",self.codes(b"# Character Kernel\n"))
    def test_missing_address_label(self):
        text=self.runtime().decode()
        text="\n".join(l for l in text.splitlines() if not l.startswith("- ユーザーからの呼ばれ方:"))
        self.assertIn("E_FIELD",self.codes(text.encode()))
    def test_examples_and_notes_reference(self):
        text=self.runtime()+"\n## 7. 会話例\n参照: character-notes.md\n".encode()
        self.assertIn("E_RUNTIME_EXAMPLES",self.codes(text))
        self.assertIn("E_RUNTIME_EXTERNAL_REFERENCE",self.codes(text))
    def test_negative_trait_is_not_a_lexical_error(self):
        self.assertTrue(self.check(self.runtime()+"\n負けず嫌い。口数が少ない。\n".encode())["structural_pass"])
    def test_utf8_and_lf(self):
        self.assertIn("E_UTF8",self.codes(b"\xff"))
        self.assertIn("E_LF",self.codes(self.runtime().replace(b"\n",b"\r\n")))
    def test_cli_runtime_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/"candidate.md"; p.write_bytes(self.runtime())
            out=io.StringIO()
            with contextlib.redirect_stdout(out): code=main(["--runtime-only",str(p)])
            self.assertEqual(code,0)
            self.assertFalse(json.loads(out.getvalue())["release_authorized"])
    def test_full_pack_still_validates_notes(self):
        d=fixture(); d["character-notes.md"]=b"# notes\n"
        self.assertFalse(Validator(CONTRACT).validate(d)["structural_pass"])

if __name__=="__main__": unittest.main()
