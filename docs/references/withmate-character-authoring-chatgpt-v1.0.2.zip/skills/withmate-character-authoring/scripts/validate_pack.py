#!/usr/bin/env python3
"""Lint a WithMate authoring-profile pack. Read-only; NEVER authorizes release.

Python 3.10+, standard library only. This is a deliberately restricted Markdown
and frontmatter reader, not a general YAML/CommonMark parser. See
required-properties.md for the accepted authoring profile and limits.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import re
import stat
import sys
from typing import Any
from urllib.parse import urlsplit, unquote
from zipfile import BadZipFile, ZipFile

MAX_INPUT_BYTES = 4 * 1024 * 1024  # A parser resource limit, not a V5 format limit.
PLACEHOLDER = re.compile(r"\{[^{}\n]+\}|<\s*(?:TBD|TODO|placeholder)[^>]*>", re.I)
EMPTY_VALUES = {"", "TBD", "TODO", "unknown", "未定", "未確認", "要確認", "...", "…"}
HEX = re.compile(r"#[0-9A-F]{6}\Z")
MANUAL_CHECKS = [
    "runtime自己完結性と採用情報の構成：意味・関係・状態の十分性、原則肯定形の人物定義、声・選択の具体性",
    "Dialogue Checkpointsの実ユーザー入力・時系列・対象候補と、各応答の出力上限",
    "各必須役割・規則の内容が十分で、Character固有であるか",
    "一人称／基本呼称の場面・省略・頻度・語気とmarker6属性の意味",
    "出典の真偽、事実・希望・設計解釈の区分、引用・権利・安全",
    "全notes項目の十分さと、未実施／不明／非該当の理由",
    "実ユーザーの照合・候補へのフィードバック・対象版承認の真正性",
    "必須品質試験の実行、未編集出力、対象revisionとの対応",
    "Notionへの操作許可・競合保護・実書き込み・再取得照合",
]


def notion_parent_id(value: str) -> str | None:
    """Syntax-only parser; does not establish existence, type, ownership or consent."""
    try:
        url = urlsplit(value)
        host = (url.hostname or '').lower()
        allowed = host in {'notion.so', 'www.notion.so', 'notion.com', 'www.notion.com', 'app.notion.com'} or host.endswith('.notion.site')
        if (url.scheme != 'https' or not allowed or url.username or url.password
                or url.port not in {None,443} or any(c.isspace() for c in value)):
            return None
        match = re.search(r'(?:^|[-/])([0-9a-fA-F]{32}|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})/?$', unquote(url.path))
        return match[1].replace('-','').lower() if match else None
    except ValueError:
        return None


@dataclass
class Section:
    level: int
    title: str
    start: int
    end: int
    lines: list[str]

    @property
    def body(self) -> str:
        return "\n".join(self.lines[self.start + 1:self.end])


def markdown_sections(text: str) -> list[Section]:
    # Headings inside comments/fenced code are not structural evidence.
    text = re.sub(r"<!--(?:[\s\S]*?-->|[\s\S]*$)", "", text)
    lines = text.splitlines()
    visible = lines.copy()
    headings: list[tuple[int, str, int]] = []
    fence_char = ""
    fence_len = 0
    for i, line in enumerate(lines):
        if fence_char:
            visible[i] = ""
            if re.fullmatch(r" {0,3}" + re.escape(fence_char) +
                            "{" + str(fence_len) + r",}\s*", line):
                fence_char = ""
            continue
        fence = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if fence:
            fence_char, fence_len = fence[1][0], len(fence[1])
            visible[i] = ""
            continue
        heading = re.match(r"^(#{1,6})\s+(.+?)(?:\s+#+)?\s*$", line)
        if heading:
            headings.append((len(heading[1]), heading[2], i))
    sections = []
    for n, (level, title, start) in enumerate(headings):
        end = next((p for lev, _, p in headings[n + 1:] if lev <= level), len(lines))
        sections.append(Section(level, title, start, end, visible))
    return sections


class Validator:
    def __init__(self, contract: dict[str, Any]):
        self.c = contract
        self.errors: list[dict[str, str]] = []
        self.warnings: list[dict[str, str]] = []
        self.metrics: dict[str, Any] = {}
        self.scope = "implemented-structural-and-record-consistency-checks-only"

    def error(self, code: str, message: str) -> None:
        self.errors.append({"code": code, "message": message})

    def warn(self, code: str, message: str) -> None:
        self.warnings.append({"code": code, "message": message})

    def section(self, sections: list[Section], level: int, title: str,
                parent: Section | None = None) -> Section | None:
        matches = [s for s in sections if s.level == level and s.title == title
                   and (parent is None or parent.start < s.start < parent.end)]
        if len(matches) != 1:
            self.error("E_SECTION", f"見出し{'#' * level} {title}: 必要1件、実際{len(matches)}件")
            return None
        sec = matches[0]
        meaningful = [line for line in sec.body.splitlines()
                      if line.strip() and not re.match(r"^\s*(?:#+\s|[-|: ]+$)", line)]
        if not meaningful:
            self.error("E_EMPTY_SECTION", f"{title}: 本文が空です")
        return sec

    def field(self, section: Section | None, key: str, required: bool = True) -> str | None:
        if section is None:
            return None
        values = re.findall(r"^-[ \t]+" + re.escape(key) + r":[ \t]*([^\n]*)$", section.body, re.M)
        if len(values) != 1:
            if required or values:
                self.error("E_FIELD", f"{section.title} / {key}: 必要1件、実際{len(values)}件")
            return None
        value = values[0].strip()
        if not value:
            self.error("E_EMPTY_FIELD", f"{section.title} / {key}: 空欄です")
        return value

    def enum(self, value: str | None, allowed: list[str], label: str) -> None:
        if value is not None and value not in allowed:
            self.error("E_ENUM", f"{label}: {value!r} は許可値ではありません")

    def array(self, value: str | None, label: str) -> list[str] | None:
        if value is None:
            return None
        try:
            result = json.loads(value)
        except (ValueError, RecursionError):
            self.error("E_ARRAY_JSON", f"{label}: JSON配列として読めません")
            return None
        if not isinstance(result, list) or not result:
            self.error("E_ARRAY_TYPE", f"{label}: 空でない配列が必要です")
            return None
        if any(not isinstance(s, str) or not s.strip() for s in result):
            self.error("E_ARRAY_ITEMS", f"{label}: 全要素が空でない文字列である必要があります")
            return None
        if len(result) != len(set(result)):
            self.error("E_ARRAY_DUPLICATE", f"{label}: 呼称が重複しています")
        return result

    def frontmatter(self, text: str) -> str:
        lines = text.splitlines()
        if not lines or lines[0] != "---":
            self.error("E_FRONTMATTER", "character.mdは先頭の---から始めてください")
            return text
        try:
            end = lines.index("---", 1)
        except ValueError:
            self.error("E_FRONTMATTER", "frontmatterの終端---がありません")
            return text
        fields: dict[str, str] = {}
        for line in lines[1:end]:
            if not line.strip():
                continue
            match = re.fullmatch(r"([a-z_]+):\s*(.*?)\s*", line)
            if not match:
                self.error("E_FRONTMATTER_SYNTAX", f"対応外のfrontmatter構文: {line!r}")
                continue
            key, value = match.groups()
            if key in fields:
                self.error("E_FRONTMATTER_DUPLICATE", f"重複キー: {key}")
            fields[key] = value
        if set(fields) != {"schema", "name", "description"}:
            self.error("E_FRONTMATTER_KEYS", f"必須3キーとの不一致: {sorted(fields)}")
        schema = fields.get("schema", "")
        if schema not in {self.c["schema"], json.dumps(self.c["schema"])}:
            self.error("E_SCHEMA", "schemaの値がwithmate-character-v5ではありません")
        for key in ["name", "description"]:
            raw = fields.get(key, "")
            try:
                value = json.loads(raw)
            except (ValueError, RecursionError):
                value = None
            if not isinstance(value, str) or not value.strip():
                self.error("E_FRONTMATTER_VALUE", f"{key}: 二重引用符付きの非空文字列が必要です")
            elif key == "description":
                self.metrics["description_chars"] = len(value)
                if len(value) > self.c["description_soft_max_chars"]:
                    self.warn("W_DESCRIPTION_LENGTH", "descriptionが160文字の目安を超えています")
        return "\n".join(lines[end + 1:])

    def check_runtime_text(self, runtime: str, raw_bytes: int) -> list[str] | None:
        """Check only implemented runtime structure; normalized text is supplied."""
        digest = sha256(runtime.encode("utf-8")).hexdigest()
        self.metrics.update(runtime_chars_lf=len(runtime), runtime_bytes=raw_bytes, runtime_sha256_lf=digest)
        if len(runtime) > self.c["runtime_max_chars"]:
            self.error("E_RUNTIME_LENGTH", "runtime全体がLF正規化後8,000文字を超えています")
        if PLACEHOLDER.search(runtime):
            self.error("E_PLACEHOLDER", "runtimeに波括弧placeholder等の候補があります。確認・解消してください")
        body = self.frontmatter(runtime)
        runtime_sections = markdown_sections(body)
        required_sections = {t: self.section(runtime_sections, 2, t) for t in self.c["runtime_h2"]}
        voice = required_sections.get("Voice Rules")
        address_array: list[str] | None = None
        for subsection, labels in self.c["voice_fields"].items():
            # Without a valid parent, a similarly named H3 elsewhere cannot pass.
            sec = self.section(runtime_sections, 3, subsection, voice) if voice else None
            for label in labels:
                value = self.field(sec, label)
                if value in EMPTY_VALUES and value is not None:
                    self.error("E_UNRESOLVED_RUNTIME", f"{label}: 採用規則が未確定です")
                if label == "ユーザーからの呼ばれ方":
                    address_array = self.array(value, "runtime呼ばれ方")
        for section in runtime_sections:
            title = re.sub(r"^(?:[0-9]+[.．、)）]?)[ \t]*", "", section.title).strip()
            if title in {"会話例", "初回メッセージ", "初回メッセージ例", "場面別台詞", "場面別台詞集"} or title.lower() in {"examples", "response examples", "initial message"}:
                self.error("E_RUNTIME_EXAMPLES", f"{section.title}: 完成返答・初回例は作成側の資料へ分離してください")
        if "character-notes.md" in runtime:
            self.error("E_RUNTIME_EXTERNAL_REFERENCE", "runtimeにcharacter-notes.mdへの参照があります。必要な採用情報を本文へ統合してください")
        return address_array

    def validate_runtime(self, data: bytes) -> dict[str, Any]:
        """Read-only candidate check; notes/colors/approval are outside this scope."""
        self.scope = "implemented-runtime-structure-only"
        if len(data) > MAX_INPUT_BYTES:
            self.error("E_INPUT_LIMIT", "runtimeが検査器の入力安全上限4MiBを超えています")
            return self.report()
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            self.error("E_UTF8", "runtimeをUTF-8として読めません")
            return self.report()
        if text.startswith("\ufeff"):
            self.error("E_BOM", "UTF-8 BOMを取り除いてください")
        if "\r" in text:
            self.error("E_LF", "保存時の改行をLFへ統一してください")
        runtime = text.replace("\r\n", "\n").replace("\r", "\n")
        self.check_runtime_text(runtime, len(data))
        return self.report()

    def validate(self, files: dict[str, bytes]) -> dict[str, Any]:
        if set(files) != set(self.c["pack_files"]):
            self.error("E_PACK_FILES", "Packはcharacter.mdとcharacter-notes.mdの2ファイルだけです")
            return self.report()
        texts: dict[str, str] = {}
        for name, data in files.items():
            if len(data) > MAX_INPUT_BYTES:
                self.error("E_INPUT_LIMIT", f"{name}: 検査器の入力安全上限4MiBを超えています")
                continue
            try:
                text = data.decode("utf-8")
            except UnicodeDecodeError:
                self.error("E_UTF8", f"{name}: UTF-8として読めません")
                continue
            if text.startswith("\ufeff"):
                self.error("E_BOM", f"{name}: UTF-8 BOMを取り除いてください")
            if "\r" in text:
                self.error("E_LF", f"{name}: 保存時の改行をLFへ統一してください")
            texts[name] = text.replace("\r\n", "\n").replace("\r", "\n")
        if len(texts) != 2:
            return self.report()
        runtime, notes = texts["character.md"], texts["character-notes.md"]
        address_array = self.check_runtime_text(runtime, len(files["character.md"]))
        digest = self.metrics["runtime_sha256_lf"]
        self.metrics["notes_bytes"] = len(files["character-notes.md"])
        if self.metrics["notes_bytes"] > self.c["notes_soft_max_bytes"]:
            self.warn("W_NOTES_LENGTH", "notesが256KiBの目安を超えています")
        ns = markdown_sections(notes)
        note_sections = {t: self.section(ns, 2, t) for t in self.c["notes_h2"]}
        closure_rule = self.c["closure_review"]
        handoff = note_sections.get(closure_rule["parent_h2"])
        closure = self.section(ns, 3, closure_rule["h3"], handoff) if handoff else None
        closure_hash = self.field(closure, "対象runtime SHA-256")
        closure_status = self.field(closure, "Review status")
        closure_evidence = self.field(closure, "Review evidence")
        self.enum(closure_status, ["pass", "fail", "inconclusive", "not-run"], "Runtime Closure Review")
        if closure_hash != digest:
            self.error("E_CLOSURE_HASH", "自己完結監査の対象hashと実runtimeが一致しません")
        if closure_status != closure_rule["pack_status_required"]:
            self.error("E_CLOSURE_REVIEW", "配布には自己完結性の意味監査pass記録が必要です。機械認証ではありません")
        if closure_evidence is None or closure_evidence in EMPTY_VALUES:
            self.error("E_CLOSURE_EVIDENCE", "自己完結性の意味監査の実施範囲・結果を追える参照を記録してください")
        self.metrics["closure_review_recorded_status"] = closure_status
        target_url = self.field(note_sections.get("Target"), "Notion parent URL")
        parent_id = notion_parent_id(target_url) if target_url else None
        if parent_id is None:
            self.error("E_NOTION_PARENT_URL", "Targetに事前作成済みNotion親ページURLが必要です（構文検査のみ）")
        else:
            self.metrics["notion_parent_id_syntax_only"] = parent_id
        parent_action = self.field(note_sections.get("Notion Sync Summary"), "Parent action", required=False)
        if parent_action is not None and parent_action not in {"updated", "unchanged", "not-run"}:
            self.error("E_NOTION_PARENT_ACTION", "親actionはupdated/unchanged/not-runのみ。この工程で親を作成しません")
        workflow = note_sections.get("Workflow State")
        mode = self.field(workflow, "Mode")
        stage = self.field(workflow, "Stage")
        revision = self.field(workflow, "Candidate revision")
        hash_record = self.field(workflow, "Candidate runtime SHA-256（LF正規化後のファイル全体）")
        approval = self.field(workflow, "Approval status")
        self.enum(mode, self.c["modes"], "Mode")
        self.enum(stage, self.c["stages"], "Stage")
        self.enum(approval, self.c["approval_statuses"], "Approval status")
        if hash_record != digest:
            self.error("E_HASH", "Workflow Stateのruntime SHA-256と実ファイルが一致しません")
        if revision in EMPTY_VALUES:
            self.error("E_REVISION", "Candidate revisionを識別できません")
        cae = note_sections.get("Character Address Evidence")
        note_array = self.array(self.field(cae, "runtime採用配列（character.mdと同じ表記・並び）"), "notes呼ばれ方")
        if address_array is not None and note_array is not None and address_array != note_array:
            self.error("E_ARRAY_MISMATCH", "runtimeとnotesの採用配列の値・並びが一致しません")
        address_status = self.field(cae, "配列の確認状態")
        self.enum(address_status, self.c["address_statuses"], "配列の確認状態")
        scope = self.field(note_sections.get("Calibration Brief"), "利用範囲")
        self.enum(scope, ["conversation-and-work", "conversation-only"], "利用範囲")
        if scope == "conversation-and-work":
            self.section(ns, 2, "Work-session Design")
            validation = note_sections.get("Validation Summary")
            if validation:
                self.section(ns, 3, "Work-session Validation Record", validation)
        colors: list[str] = []
        color_section = note_sections.get("Visual Identity / Color Notes")
        if color_section:
            for role in ["メインカラー", "サブカラー"]:
                rows = [line for line in color_section.body.splitlines()
                        if re.match(r"^\|\s*" + re.escape(role) + r"\s*\|", line)]
                if len(rows) != 1:
                    self.error("E_COLOR_ROW", f"{role}: 表に1行必要です（実際{len(rows)}行）")
                    continue
                cells = [c.strip() for c in rows[0].strip().strip("|").split("|")]
                if len(cells) < 7 or not HEX.fullmatch(cells[1]):
                    self.error("E_COLOR_HEX", f"{role}: 7列の既定表と大文字#RRGGBBが必要です")
                    continue
                colors.append(cells[1])
                if cells[2] not in {"official-published", "official-sampled", "authoring-derived"}:
                    self.error("E_COLOR_CLASS", f"{role}: 決定区分が不正です")
                if any(not c for c in cells[3:7]):
                    self.error("E_COLOR_EVIDENCE", f"{role}: 根拠・方法・理由・不確実性の記録に空欄があります")
        ar = note_sections.get("Approval Record")
        ar_status = self.field(ar, "Approval status")
        if ar_status != approval:
            self.error("E_APPROVAL_MISMATCH", "Workflow StateとApproval Recordのstatusが不一致です")
        if mode == "one-shot" and (stage != "provisional" or approval != "waived"):
            self.error("E_ONESHOT", "one-shotの配布記録はstage=provisional、approval=waivedです")
        if (stage == "approved") != (approval == "approved"):
            self.error("E_APPROVED_STATE", "stage=approvedとapproval=approvedの記録が対応していません")
        if stage == "approved":
            if address_status != "confirmed":
                self.error("E_ADDRESS_APPROVAL", "approvedには呼ばれ方集合のconfirmedが必要です")
            target = self.field(ar, "対象revision / runtime hash") or ""
            if not revision or target != f"{revision} / {digest}":
                self.error("E_APPROVAL_TARGET", "承認記録の対象revision/hashが現在版と一致しません")
            self.field(ar, "明示的な採用の確認日・会話参照または短い記録")
            approved_colors = self.field(ar, "対象メインHEX / サブHEX") or ""
            if len(colors) != 2 or approved_colors.split(" / ") != colors:
                self.error("E_APPROVAL_COLORS", "承認対象2色と現在の色が一致しません")
        return self.report()

    def report(self) -> dict[str, Any]:
        return {
            "profile": self.c["profile"],
            "structural_pass": not self.errors,
            "release_authorized": False,
            "scope": self.scope,
            "errors": self.errors,
            "warnings": self.warnings,
            "metrics": self.metrics,
            "manual_checks_required": (MANUAL_CHECKS if self.scope != "implemented-runtime-structure-only" else [MANUAL_CHECKS[i] for i in (0, 2, 3, 4, 7)]),
            "notice": "承認・自己完結監査の記録は自己申告データの照合です。意味の自己完結性、実承認、品質、Notion同期を認証しません。",
        }


def load_pack(path: Path, expected_names: list[str]) -> dict[str, bytes]:
    expected = sorted(expected_names)
    if path.is_dir():
        entries = list(path.iterdir())
        if sorted(p.name for p in entries) != expected:
            raise ValueError("検査対象directoryの直下を2ファイルだけにしてください")
        if any(p.is_symlink() or not p.is_file() for p in entries):
            raise ValueError("directoryやsymlinkはPackに入れられません")
        if any(p.stat().st_size > MAX_INPUT_BYTES for p in entries):
            raise ValueError("検査器のファイル入力安全上限4MiBを超えています")
        return {p.name: p.read_bytes() for p in entries}
    with ZipFile(path) as z:
        entries = z.infolist()
        if sorted(i.filename for i in entries) != expected:
            raise ValueError("Zipはroot直下の2ファイルのみです。余分な項目・重複・階層を除いてください")
        data = {}
        for entry in entries:
            if entry.is_dir() or stat.S_ISLNK(entry.external_attr >> 16):
                raise ValueError("Zipにdirectoryやsymlinkは入れられません")
            if entry.file_size > MAX_INPUT_BYTES:
                raise ValueError("Zip展開サイズが検査器の安全上限4MiBを超えています")
            with z.open(entry) as stream:
                content = stream.read(MAX_INPUT_BYTES + 1)
            if len(content) > MAX_INPUT_BYTES:
                raise ValueError("Zipの実データが検査器の安全上限を超えています")
            data[entry.filename] = content
        return data


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("pack", type=Path, help="CharacterPack Zip、または2ファイルだけのdirectory")
    p.add_argument("--runtime-only", action="store_true", help="候補本文だけを検査。notes・色・承認記録は対象外")
    p.add_argument("--contract", type=Path, default=Path(__file__).with_name("validation-contract.json"))
    p.add_argument("--reference-dir", type=Path, help="最終原稿2ファイルのdirectory。Zipとbyte比較します")
    args = p.parse_args(argv)
    try:
        contract = json.loads(args.contract.read_text(encoding="utf-8"))
        validator = Validator(contract)
        if args.runtime_only:
            if args.reference_dir is not None:
                raise ValueError("--runtime-onlyと--reference-dirは同時に指定できません")
            if args.pack.is_symlink() or not args.pack.is_file():
                raise ValueError("--runtime-onlyには通常のMarkdownファイルを指定してください")
            if args.pack.stat().st_size > MAX_INPUT_BYTES:
                raise ValueError("runtimeが入力安全上限4MiBを超えています")
            validator.validate_runtime(args.pack.read_bytes())
        else:
            files = load_pack(args.pack, contract["pack_files"])
            validator.validate(files)
            if args.reference_dir is not None:
                if not args.reference_dir.is_dir():
                    raise ValueError("--reference-dirは2ファイルを格納したdirectoryを指定してください")
                reference = load_pack(args.reference_dir, contract["pack_files"])
                for name in contract["pack_files"]:
                    if files[name] != reference[name]:
                        validator.error("E_PACKAGING_BYTES", f"{name}: Zipと最終原稿のbyteが一致しません")
                validator.metrics["reference_byte_comparison"] = all(files[n] == reference[n] for n in contract["pack_files"])
        report = validator.report()
    except (OSError, ValueError, KeyError, TypeError, BadZipFile, RuntimeError) as exc:
        print(json.dumps({"structural_pass": False, "release_authorized": False,
                          "errors": [{"code": "E_INPUT", "message": str(exc)}]}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["structural_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
