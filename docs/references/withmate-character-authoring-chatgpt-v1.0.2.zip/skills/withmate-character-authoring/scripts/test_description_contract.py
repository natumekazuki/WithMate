"""Static description-authoring contract checks, not an LLM or voice-quality eval."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DescriptionContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.entry = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        cls.format = (ROOT / 'references/withmate-v5-character-format.md').read_text(encoding='utf-8')
        cls.description = cls.format.split('## Frontmatter Description\n', 1)[1].split('\n## ', 1)[0]
        cls.review = (ROOT / 'references/review-checklist.md').read_text(encoding='utf-8')
        cls.template = (ROOT / 'assets/character.md').read_text(encoding='utf-8')
        cls.provenance = json.loads((ROOT / 'references/provenance.json').read_text(encoding='utf-8'))

    def test_entry_requires_character_self_introduction_not_plugin_bio(self):
        for text in ['キャラ本人が相手へ直接語る簡潔な自己紹介', '第三者紹介',
                     'Voice Rules', 'プラグイン／Skill自体のdescriptionはこの要件の対象外']:
            self.assertIn(text, self.entry)

    def test_voice_matches_character_without_forcing_watashi(self):
        for text in ['一人称の正確な表記', '敬語度', '語尾', '文のテンポ', '距離感',
                     '「私」を一律に付け', '主語省略', '自分の名前を一人称']:
            self.assertIn(text, self.description)

    def test_sources_support_facts_not_third_person_copying(self):
        for text in ['採用する事実・設定の根拠', '第三者視点の原文を維持する指示ではない',
                     '一次設定・創作者設定', '本人の言葉で書き直す',
                     'Frontmatter Description Notes', '実発言', '創作せず']:
            self.assertIn(text, self.description)

    def test_concise_metadata_is_not_a_fixed_initial_reply(self):
        for text in ['1〜3文・160文字以内', 'プロフィール用メタデータ',
                     '初回メッセージ', '毎ターンの挨拶や固定返答',
                     'revision/hash', '採用承認']:
            self.assertIn(text, self.description)

    def test_review_is_semantic_not_a_pronoun_regex(self):
        self.assertIn('一人称の有無だけの正規表現では合否を決めず', self.description)
        self.assertIn('構造検査とは別の意味・文体レビュー', self.description)
        for text in ['本人が自分を簡潔に語る自己紹介', 'Voice Rulesと一致',
                     '一次根拠', '自己紹介への言い換え', '構造検査とは別にレビュー']:
            self.assertIn(text, self.review)

    def test_runtime_template_changes_only_description_placeholder(self):
        current = '{character_self_introduction_in_own_voice}'
        self.assertEqual(self.template.count(current), 1)
        restored = self.template.replace(current, '{character_profile_bio}', 1)
        self.assertEqual(hashlib.sha256(restored.encode('utf-8')).hexdigest(),
                         self.provenance['preserved_runtime_template_sha256'])
        self.assertEqual(hashlib.sha256(self.template.encode('utf-8')).hexdigest(),
                         self.provenance['current_runtime_template_sha256'])

    def test_frontmatter_contract_and_body_architecture_are_unchanged(self):
        frontmatter = self.template.split('---\n', 2)[1]
        pairs = dict(line.split(': ', 1) for line in frontmatter.splitlines())
        self.assertEqual(set(pairs), {'schema', 'name', 'description'})
        self.assertEqual(pairs['schema'], 'withmate-character-v5')
        self.assertEqual(json.loads(pairs['description']), '{character_self_introduction_in_own_voice}')
        self.assertEqual(sum(line.startswith('## ') for line in self.template.splitlines()), 10)

    def test_changed_skill_files_match_manifest_and_no_behavior_claim(self):
        manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
        for name in ['SKILL.md', 'assets/character.md',
                     'references/withmate-v5-character-format.md',
                     'references/review-checklist.md', 'references/provenance.json',
                     'scripts/test_skill_package.py', 'scripts/test_description_contract.py']:
            with self.subTest(name=name):
                data = (ROOT / name).read_bytes()
                self.assertEqual(manifest['files'][name]['bytes'], len(data))
                self.assertEqual(manifest['files'][name]['sha256'], hashlib.sha256(data).hexdigest())
        self.assertEqual(manifest['version'], self.provenance['skill_version'])
        self.assertFalse(self.provenance['model_behavior_verified'])


if __name__ == '__main__':
    unittest.main()
