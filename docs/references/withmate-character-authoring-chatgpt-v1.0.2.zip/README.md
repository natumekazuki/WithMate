# WithMate Character Authoring

Version 1.0.2 — private skills-only plugin / source basis r5.

`skills/withmate-character-authoring/SKILL.md`が入口です。Skillはキャラ制作の共通手順であり、個別CharacterPackではありません。検索・ファイル操作・Python・Notionは実行先で利用できる機能を使います。APIキー、外部サーバー、追加の書込権限は含みません。

ChatGPTのプラグイン画面でこのPluginを追加し、作成依頼で選択します。対象名、既知の希望、事前作成済みNotion親URLを添えてください。初回は調査したキャラ像の照合を返し、次の実ユーザー入力から候補試演へ進みます。

Projectの旧共通仕様とこのSkillを併存した正本にせず、短い起動指示と案件固有資料へ分けてください。既存Project設定・既存キャラ・Notionは、このPlugin登録によって自動変更されません。

生成する`character.md`の`description`は、第三者による人物説明ではなく、キャラ本人の一人称・口調による簡潔な自己紹介です。1〜3文・160文字以内を目安とし、根拠のある設定とVoice Rulesに合わせます。本人に特徴的な挨拶・名乗りがある場合は、使用文脈と表記を確認して自己紹介へ自然に取り入れます。ない場合には無理に作りません。

## ローカル検査

Skillルートで実行します。Python 3.10以上、標準ライブラリのみ。

```bash
python -B scripts/read_stage.py --verify
python -B scripts/read_stage.py --check-plan
python -B -m unittest discover -s scripts -p 'test_*.py' -v
python -B scripts/validate_pack.py --runtime-only /path/to/character.md
python -B scripts/validate_pack.py /path/to/CharacterPack.zip --reference-dir /path/to/final/files
```

単体テストは構造・参照・記録整合の確認です。実ユーザーの承認、Characterらしさ、モデルが返答を待つ動作の証明ではありません。受入試験の計画は配布時の移行・検証記録を参照してください。
